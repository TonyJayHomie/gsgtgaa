@echo off
echo ============================================
echo  RSCTransfer - Build EXE
echo ============================================

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Install from python.org
    pause
    exit /b 1
)

:: Install deps
echo Installing dependencies...
pip install cryptography pyinstaller --quiet

:: Build
echo Building EXE...
pyinstaller ^
    --onefile ^
    --windowed ^
    --name RSCTransfer ^
    --icon NONE ^
    --add-data "." ^
    RSCTransfer.py

echo.
if exist dist\RSCTransfer.exe (
    echo SUCCESS: dist\RSCTransfer.exe is ready
) else (
    echo FAILED: Check output above for errors
)
pause
