"""
RSCTransfer - GTA Online Character Transfer Tool
=================================================
Captures GTA Online character init data via local HTTPS proxy,
then injects it into a different Social Club account session.

Requirements:
    pip install cryptography

Usage:
    python RSCTransfer.py
    (or double-click RSCTransfer.exe)

How it works:
    1. Generates a root CA cert and installs it into Windows trusted store
    2. Runs a local HTTPS MITM proxy (default port 8080)
    3. You set Windows proxy to 127.0.0.1:8080
    4. Launch GTA Online with Account A (Xbox account) — proxy captures
       the Rockstar character initialization payload
    5. Switch to Account B (PC account), proxy injects the saved payload
       so GTA sees Account A's character
    6. Run alongside FSL so saves stay local and don't get overwritten

NOTE: Rockstar may use certificate pinning on some endpoints.
      If capture shows empty results, pinning is active on that call.
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog
import threading
import socket
import ssl
import json
import os
import re
import gzip
import zlib
import time
import datetime
import queue
import select
import struct
import hashlib
import subprocess
import tempfile
import shutil
from pathlib import Path
from typing import Optional, Dict, List, Tuple

# ── cryptography ──────────────────────────────────────────────────────────────
try:
    from cryptography import x509
    from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.hazmat.backends import default_backend
    import ipaddress
    CRYPTO_OK = True
except ImportError:
    CRYPTO_OK = False

# ── Constants ─────────────────────────────────────────────────────────────────
APP_NAME    = "RSCTransfer"
APP_VER     = "1.0.0"
DATA_DIR    = Path(os.environ.get("APPDATA", ".")) / "RSCTransfer"
CERT_DIR    = DATA_DIR / "certs"
CAPTURE_DIR = DATA_DIR / "captures"
CA_CERT     = CERT_DIR / "RSCTransfer_CA.crt"
CA_KEY      = CERT_DIR / "RSCTransfer_CA.key"
DEFAULT_PORT = 8080

# Rockstar domains to intercept
RSC_DOMAINS = {
    "rockstargames.com",
    "cloud.rockstargames.com",
    "scapi.rockstargames.com",
    "online.rockstargames.com",
    "title.rockstargames.com",
    "prod.cloud.rockstargames.com",
    "auth.rockstargames.com",
    "api.rockstargames.com",
    "gtav.cloud.rockstargames.com",
}

# JSON keys that signal character data
CHAR_SIGNALS = {
    "characterData", "character", "mpChars", "CharData",
    "characterId", "charIndex", "rankData", "statsData",
    "charAppearance", "mpCharInfo", "gtavMpChar",
}

# ── Certificate helpers ───────────────────────────────────────────────────────

def _make_name(cn: str) -> x509.Name:
    return x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "US"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, APP_NAME),
        x509.NameAttribute(NameOID.COMMON_NAME, cn),
    ])


def generate_ca() -> Tuple[bytes, bytes]:
    """Generate root CA key + self-signed cert. Returns (cert_pem, key_pem)."""
    key = rsa.generate_private_key(
        public_exponent=65537, key_size=2048, backend=default_backend()
    )
    now = datetime.datetime.utcnow()
    cert = (
        x509.CertificateBuilder()
        .subject_name(_make_name(f"{APP_NAME} Root CA"))
        .issuer_name(_make_name(f"{APP_NAME} Root CA"))
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + datetime.timedelta(days=3650))
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .add_extension(
            x509.KeyUsage(
                digital_signature=True, key_cert_sign=True, crl_sign=True,
                content_commitment=False, key_encipherment=False,
                data_encipherment=False, key_agreement=False,
                encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .sign(key, hashes.SHA256(), default_backend())
    )
    return (
        cert.public_bytes(serialization.Encoding.PEM),
        key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption(),
        ),
    )


def generate_host_cert(hostname: str, ca_cert_pem: bytes, ca_key_pem: bytes) -> Tuple[bytes, bytes]:
    """Generate a host cert signed by our CA."""
    ca_cert = x509.load_pem_x509_certificate(ca_cert_pem, default_backend())
    ca_key_obj = serialization.load_pem_private_key(ca_key_pem, password=None, backend=default_backend())

    key = rsa.generate_private_key(
        public_exponent=65537, key_size=2048, backend=default_backend()
    )
    now = datetime.datetime.utcnow()

    # Build SAN
    san_list = [x509.DNSName(hostname)]
    if hostname.startswith("*."):
        san_list.append(x509.DNSName(hostname[2:]))

    cert = (
        x509.CertificateBuilder()
        .subject_name(_make_name(hostname))
        .issuer_name(ca_cert.subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + datetime.timedelta(days=365))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(x509.SubjectAlternativeName(san_list), critical=False)
        .add_extension(
            x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False
        )
        .sign(ca_key_obj, hashes.SHA256(), default_backend())
    )
    return (
        cert.public_bytes(serialization.Encoding.PEM),
        key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption(),
        ),
    )


def install_ca_windows(cert_path: Path) -> bool:
    """Import the CA cert into Windows Trusted Root store (requires elevation prompt)."""
    cmd = [
        "certutil", "-addstore", "-user", "Root", str(cert_path)
    ]
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=30)
        return r.returncode == 0
    except Exception:
        return False


def remove_ca_windows(cert_path: Path) -> bool:
    """Remove the CA cert from Windows Trusted Root store."""
    cmd = [
        "certutil", "-delstore", "-user", "Root", APP_NAME
    ]
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=30)
        return r.returncode == 0
    except Exception:
        return False


# ── Cert cache (per-host certs generated on demand) ──────────────────────────

class CertCache:
    def __init__(self, ca_cert_pem: bytes, ca_key_pem: bytes):
        self._ca_cert = ca_cert_pem
        self._ca_key  = ca_key_pem
        self._cache: Dict[str, Tuple[bytes, bytes]] = {}

    def get(self, hostname: str) -> Tuple[bytes, bytes]:
        if hostname not in self._cache:
            self._cache[hostname] = generate_host_cert(hostname, self._ca_cert, self._ca_key)
        return self._cache[hostname]


# ── HTTP body decode ──────────────────────────────────────────────────────────

def decode_body(raw: bytes, encoding: str) -> bytes:
    enc = encoding.lower().strip()
    try:
        if enc == "gzip":
            return gzip.decompress(raw)
        if enc in ("deflate", "zlib"):
            return zlib.decompress(raw)
    except Exception:
        pass
    return raw


def parse_http_response(data: bytes) -> Tuple[int, Dict[str, str], bytes]:
    """Parse raw HTTP/1.x response. Returns (status, headers, body)."""
    try:
        header_end = data.index(b"\r\n\r\n")
    except ValueError:
        return 0, {}, data

    header_part = data[:header_end].decode("utf-8", errors="replace")
    body_raw    = data[header_end + 4:]

    lines   = header_part.split("\r\n")
    status  = int(lines[0].split()[1]) if len(lines) > 0 else 0
    headers = {}
    for line in lines[1:]:
        if ":" in line:
            k, _, v = line.partition(":")
            headers[k.strip().lower()] = v.strip()

    # Handle chunked
    if headers.get("transfer-encoding", "").lower() == "chunked":
        body_raw = _dechunk(body_raw)

    body = decode_body(body_raw, headers.get("content-encoding", ""))
    return status, headers, body


def _dechunk(data: bytes) -> bytes:
    out = b""
    while data:
        try:
            end = data.index(b"\r\n")
        except ValueError:
            break
        size = int(data[:end], 16)
        if size == 0:
            break
        out  += data[end + 2: end + 2 + size]
        data  = data[end + 2 + size + 2:]
    return out


# ── Capture record ────────────────────────────────────────────────────────────

class Capture:
    def __init__(self, host: str, path: str, method: str,
                 status: int, body: bytes, ts: float):
        self.host    = host
        self.path    = path
        self.method  = method
        self.status  = status
        self.body    = body
        self.ts      = ts
        self.ts_str  = datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
        self.is_char = self._detect()
        self.label   = f"[{'★' if self.is_char else ' '}] {self.method} {host}{path} ({status})"

    def _detect(self) -> bool:
        try:
            txt = self.body.decode("utf-8", errors="replace")
            return any(sig in txt for sig in CHAR_SIGNALS)
        except Exception:
            return False

    def to_dict(self) -> dict:
        return {
            "host":    self.host,
            "path":    self.path,
            "method":  self.method,
            "status":  self.status,
            "body":    self.body.decode("utf-8", errors="replace"),
            "ts":      self.ts,
            "is_char": self.is_char,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Capture":
        c = cls.__new__(cls)
        c.host    = d["host"]
        c.path    = d["path"]
        c.method  = d["method"]
        c.status  = d["status"]
        c.body    = d["body"].encode("utf-8")
        c.ts      = d["ts"]
        c.ts_str  = datetime.datetime.fromtimestamp(c.ts).strftime("%Y-%m-%d %H:%M:%S")
        c.is_char = d.get("is_char", False)
        c.label   = f"[{'★' if c.is_char else ' '}] {c.method} {c.host}{c.path} ({c.status})"
        return c


# ── MITM Proxy ────────────────────────────────────────────────────────────────

class MITMProxy:
    """
    Listens for HTTP CONNECT, intercepts HTTPS traffic for Rockstar domains,
    passes everything else through transparently.
    """

    def __init__(self, port: int, cert_cache: CertCache,
                 log_q: queue.Queue, capture_q: queue.Queue,
                 inject_mode: bool = False,
                 inject_map: Optional[Dict[str, bytes]] = None):
        self.port        = port
        self.cert_cache  = cert_cache
        self.log_q       = log_q
        self.capture_q   = capture_q
        self.inject_mode = inject_mode
        self.inject_map  = inject_map or {}
        self._server_sock: Optional[socket.socket] = None
        self._running    = False

    def start(self):
        self._server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server_sock.bind(("0.0.0.0", self.port))
        self._server_sock.listen(100)
        self._server_sock.settimeout(1.0)
        self._running = True
        self._log(f"Proxy listening on port {self.port}")
        while self._running:
            try:
                client_sock, addr = self._server_sock.accept()
                t = threading.Thread(target=self._handle, args=(client_sock,), daemon=True)
                t.start()
            except socket.timeout:
                continue
            except OSError:
                break

    def stop(self):
        self._running = False
        if self._server_sock:
            try:
                self._server_sock.close()
            except Exception:
                pass

    def _log(self, msg: str):
        self.log_q.put(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] {msg}")

    def _handle(self, client_sock: socket.socket):
        try:
            client_sock.settimeout(10)
            data = b""
            while b"\r\n\r\n" not in data:
                chunk = client_sock.recv(4096)
                if not chunk:
                    return
                data += chunk

            first_line = data.split(b"\r\n")[0].decode("utf-8", errors="replace")
            parts = first_line.split()
            if len(parts) < 3:
                return

            method = parts[0]

            if method == "CONNECT":
                self._handle_connect(client_sock, parts[1])
            else:
                # Plain HTTP — just forward
                self._forward_plain(client_sock, data)
        except Exception as e:
            pass
        finally:
            try:
                client_sock.close()
            except Exception:
                pass

    def _handle_connect(self, client_sock: socket.socket, host_port: str):
        if ":" in host_port:
            host, port_s = host_port.rsplit(":", 1)
            port = int(port_s)
        else:
            host, port = host_port, 443

        # Tell client we're connected
        client_sock.sendall(b"HTTP/1.1 200 Connection established\r\n\r\n")

        # Should we intercept?
        should_intercept = any(host.endswith(d) for d in RSC_DOMAINS)

        if not should_intercept:
            # Transparent tunnel
            self._tunnel(client_sock, host, port)
            return

        # SSL intercept
        cert_pem, key_pem = self.cert_cache.get(host)

        # Write cert/key to temp files for ssl.wrap_socket
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pem") as cf:
            cf.write(cert_pem)
            cert_file = cf.name
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pem") as kf:
            kf.write(key_pem)
            key_file = kf.name

        try:
            ctx_srv = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ctx_srv.load_cert_chain(cert_file, key_file)
            client_tls = ctx_srv.wrap_socket(client_sock, server_side=True)

            # Connect to real server
            raw_server = socket.create_connection((host, port), timeout=10)
            ctx_cli = ssl.create_default_context()
            server_tls = ctx_cli.wrap_socket(raw_server, server_hostname=host)

            self._intercept_loop(client_tls, server_tls, host)
        except Exception as e:
            self._log(f"SSL intercept failed for {host}: {e}")
            self._tunnel(client_sock, host, port)
        finally:
            os.unlink(cert_file)
            os.unlink(key_file)

    def _intercept_loop(self, client: ssl.SSLSocket, server: ssl.SSLSocket, host: str):
        """Read full request from client, forward to server, capture response."""
        try:
            client.settimeout(15)
            server.settimeout(15)

            # Read client request
            req_data = b""
            while True:
                try:
                    chunk = client.recv(8192)
                    if not chunk:
                        break
                    req_data += chunk
                    if b"\r\n\r\n" in req_data:
                        # Check content-length for body
                        header_end = req_data.index(b"\r\n\r\n")
                        headers_raw = req_data[:header_end].decode("utf-8", errors="replace")
                        cl_match = re.search(r"content-length:\s*(\d+)", headers_raw, re.I)
                        if cl_match:
                            cl = int(cl_match.group(1))
                            body_so_far = len(req_data) - header_end - 4
                            if body_so_far >= cl:
                                break
                        else:
                            break
                except socket.timeout:
                    break

            if not req_data:
                return

            # Parse method + path
            first_line = req_data.split(b"\r\n")[0].decode("utf-8", errors="replace")
            parts      = first_line.split()
            method     = parts[0] if parts else "GET"
            path       = parts[1] if len(parts) > 1 else "/"

            # Check inject mode
            inject_key = f"{host}{path}"
            if self.inject_mode and inject_key in self.inject_map:
                # Serve injected body instead of real response
                injected = self.inject_map[inject_key]
                resp = (
                    b"HTTP/1.1 200 OK\r\n"
                    b"Content-Type: application/json\r\n"
                    b"Content-Length: " + str(len(injected)).encode() + b"\r\n"
                    b"Connection: close\r\n\r\n"
                ) + injected
                client.sendall(resp)
                self._log(f"INJECTED → {host}{path}")
                return

            # Forward request to server
            server.sendall(req_data)

            # Read server response
            resp_data = b""
            while True:
                try:
                    chunk = server.recv(8192)
                    if not chunk:
                        break
                    resp_data += chunk
                except socket.timeout:
                    break

            # Forward response to client
            if resp_data:
                client.sendall(resp_data)

            # Parse and maybe capture
            status, headers, body = parse_http_response(resp_data)
            ct = headers.get("content-type", "")
            if "json" in ct or "javascript" in ct:
                cap = Capture(host, path, method, status, body, time.time())
                self._log(f"{'★ CHAR ' if cap.is_char else ''}{'CAPTURE'} {method} {host}{path} → {status} ({len(body)}b)")
                self.capture_q.put(cap)

        except Exception as e:
            self._log(f"Intercept loop error on {host}: {e}")
        finally:
            try:
                client.close()
            except Exception:
                pass
            try:
                server.close()
            except Exception:
                pass

    def _tunnel(self, client_sock: socket.socket, host: str, port: int):
        """Blind TCP tunnel — no interception."""
        try:
            server_sock = socket.create_connection((host, port), timeout=10)
        except Exception:
            return

        socks = [client_sock, server_sock]
        try:
            while True:
                readable, _, _ = select.select(socks, [], socks, 5)
                if not readable:
                    break
                for s in readable:
                    other = server_sock if s is client_sock else client_sock
                    try:
                        data = s.recv(8192)
                        if not data:
                            return
                        other.sendall(data)
                    except Exception:
                        return
        finally:
            try:
                server_sock.close()
            except Exception:
                pass

    def _forward_plain(self, client_sock: socket.socket, data: bytes):
        """Forward plain HTTP request."""
        # Extract Host header
        match = re.search(rb"Host:\s*([^\r\n]+)", data, re.I)
        if not match:
            return
        host_hdr = match.group(1).decode("utf-8", errors="replace").strip()
        host = host_hdr.split(":")[0]
        port = int(host_hdr.split(":")[1]) if ":" in host_hdr else 80
        try:
            server = socket.create_connection((host, port), timeout=10)
            server.sendall(data)
            resp = b""
            while True:
                try:
                    chunk = server.recv(8192)
                    if not chunk:
                        break
                    resp += chunk
                except socket.timeout:
                    break
            client_sock.sendall(resp)
        except Exception:
            pass
        finally:
            try:
                server.close()
            except Exception:
                pass


# ── Main App ──────────────────────────────────────────────────────────────────

class RSCTransferApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} v{APP_VER} — GTA Online Character Transfer")
        self.geometry("900x650")
        self.resizable(True, True)
        self.configure(bg="#1a1a2e")

        # State
        self._proxy_thread: Optional[threading.Thread] = None
        self._proxy: Optional[MITMProxy] = None
        self._running = False
        self._cert_cache: Optional[CertCache] = None
        self._captures: List[Capture] = []
        self._inject_map: Dict[str, bytes] = {}
        self._log_q:     queue.Queue = queue.Queue()
        self._capture_q: queue.Queue = queue.Queue()

        # Dirs
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        CERT_DIR.mkdir(parents=True, exist_ok=True)
        CAPTURE_DIR.mkdir(parents=True, exist_ok=True)

        self._build_ui()
        self._poll_queues()

        # Load CA if exists
        if CA_CERT.exists() and CA_KEY.exists():
            self._load_ca()

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        # Colour palette
        BG  = "#1a1a2e"
        FG  = "#e0e0e0"
        ACC = "#00b4d8"
        BTN = "#0077b6"
        DRK = "#16213e"

        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TNotebook",         background=BG,  borderwidth=0)
        style.configure("TNotebook.Tab",     background=DRK, foreground=FG,
                        padding=[12, 6], font=("Consolas", 10, "bold"))
        style.map("TNotebook.Tab",
                  background=[("selected", ACC)],
                  foreground=[("selected", "#000")])
        style.configure("TFrame",      background=BG)
        style.configure("TLabel",      background=BG, foreground=FG,
                        font=("Consolas", 10))
        style.configure("TButton",     background=BTN, foreground=FG,
                        font=("Consolas", 10, "bold"), borderwidth=0)
        style.map("TButton",
                  background=[("active", ACC)],
                  foreground=[("active", "#000")])
        style.configure("TLabelframe", background=BG, foreground=ACC,
                        font=("Consolas", 10, "bold"))
        style.configure("TLabelframe.Label", background=BG, foreground=ACC)
        style.configure("TEntry",      fieldbackground=DRK, foreground=FG,
                        insertcolor=FG)
        style.configure("TListbox",    background=DRK, foreground=FG)

        # Header
        hdr = tk.Frame(self, bg="#0077b6", pady=6)
        hdr.pack(fill=tk.X)
        tk.Label(hdr, text=f"  ▶  {APP_NAME}  — GTA Online Character Transfer",
                 bg="#0077b6", fg="white",
                 font=("Consolas", 13, "bold")).pack(side=tk.LEFT)
        tk.Label(hdr, text=f"v{APP_VER}  ",
                 bg="#0077b6", fg="#cce7ff",
                 font=("Consolas", 10)).pack(side=tk.RIGHT)

        # Tabs
        self._nb = ttk.Notebook(self)
        self._nb.pack(fill=tk.BOTH, expand=True, padx=6, pady=6)

        self._tab_setup   = ttk.Frame(self._nb)
        self._tab_capture = ttk.Frame(self._nb)
        self._tab_inject  = ttk.Frame(self._nb)
        self._tab_log     = ttk.Frame(self._nb)

        self._nb.add(self._tab_setup,   text="  ① Setup  ")
        self._nb.add(self._tab_capture, text="  ② Capture  ")
        self._nb.add(self._tab_inject,  text="  ③ Inject  ")
        self._nb.add(self._tab_log,     text="  ④ Log  ")

        self._build_setup_tab()
        self._build_capture_tab()
        self._build_inject_tab()
        self._build_log_tab()

        # Status bar
        self._status_var = tk.StringVar(value="Ready. Start with Setup tab.")
        sb = tk.Label(self, textvariable=self._status_var,
                      bg="#0d0d1a", fg="#00b4d8",
                      font=("Consolas", 9), anchor=tk.W, pady=3)
        sb.pack(fill=tk.X, side=tk.BOTTOM)

    # ── Setup tab ─────────────────────────────────────────────────────────────

    def _build_setup_tab(self):
        f = self._tab_setup
        pad = {"padx": 12, "pady": 6}

        # Step 1 — CA cert
        lf1 = ttk.LabelFrame(f, text=" Step 1 — Generate & Install CA Certificate ")
        lf1.pack(fill=tk.X, **pad)

        tk.Label(lf1, text=(
            "RSCTransfer needs a root certificate so GTA's HTTPS traffic\n"
            "can be intercepted on your PC. This cert is installed ONLY in\n"
            "your personal Windows certificate store (not system-wide).\n"
            "You can remove it any time with the button below."
        ), justify=tk.LEFT).pack(anchor=tk.W, padx=8, pady=4)

        self._cert_status = tk.StringVar(value="◌  No certificate found")
        tk.Label(lf1, textvariable=self._cert_status,
                 font=("Consolas", 10, "bold"), fg="#ffd166").pack(anchor=tk.W, padx=8)

        bf = tk.Frame(lf1, bg="#1a1a2e")
        bf.pack(fill=tk.X, padx=8, pady=6)
        ttk.Button(bf, text="Generate + Install CA",
                   command=self._do_generate_ca).pack(side=tk.LEFT, padx=4)
        ttk.Button(bf, text="Remove CA",
                   command=self._do_remove_ca).pack(side=tk.LEFT, padx=4)

        # Step 2 — Proxy port
        lf2 = ttk.LabelFrame(f, text=" Step 2 — Configure Proxy Port ")
        lf2.pack(fill=tk.X, **pad)

        pf = tk.Frame(lf2, bg="#1a1a2e")
        pf.pack(fill=tk.X, padx=8, pady=6)
        tk.Label(pf, text="Proxy port:").pack(side=tk.LEFT)
        self._port_var = tk.StringVar(value=str(DEFAULT_PORT))
        tk.Entry(pf, textvariable=self._port_var, width=8,
                 font=("Consolas", 11)).pack(side=tk.LEFT, padx=6)

        # Step 3 — Windows proxy setting instructions
        lf3 = ttk.LabelFrame(f, text=" Step 3 — Set Windows System Proxy ")
        lf3.pack(fill=tk.X, **pad)

        tk.Label(lf3, text=(
            "After starting the proxy (Capture tab), set your system proxy:\n\n"
            "  Windows Settings → Network & Internet → Proxy\n"
            "  → Manual proxy setup → ON\n"
            "  → Address: 127.0.0.1    Port: (your port above)\n\n"
            "GTA Online will route through this proxy automatically.\n"
            "Disable the system proxy after you are done."
        ), justify=tk.LEFT).pack(anchor=tk.W, padx=8, pady=4)

        ttk.Button(lf3, text="Open Windows Proxy Settings",
                   command=lambda: subprocess.Popen(
                       ["start", "ms-settings:network-proxy"], shell=True
                   )).pack(padx=8, pady=4, anchor=tk.W)

        # Step 4 — Xbox account note
        lf4 = ttk.LabelFrame(f, text=" Step 4 — Account Switching Guide ")
        lf4.pack(fill=tk.X, **pad)

        tk.Label(lf4, text=(
            "CAPTURE PHASE:\n"
            "  • Sign into Rockstar Social Club with your XBOX account\n"
            "  • Launch GTA Online — let it fully load into a session\n"
            "  • The proxy captures character init payloads (★ marked)\n\n"
            "INJECT PHASE:\n"
            "  • Sign out, sign in with your PC Social Club account\n"
            "  • Switch to Inject tab, select the captured ★ payloads\n"
            "  • Enable inject, launch GTA Online\n"
            "  • Run FSL alongside this to prevent server save overwrites"
        ), justify=tk.LEFT).pack(anchor=tk.W, padx=8, pady=4)

    # ── Capture tab ───────────────────────────────────────────────────────────

    def _build_capture_tab(self):
        f = self._tab_capture

        ctrl = tk.Frame(f, bg="#1a1a2e")
        ctrl.pack(fill=tk.X, padx=12, pady=8)

        self._proxy_btn = ttk.Button(ctrl, text="▶  Start Proxy",
                                     command=self._toggle_proxy)
        self._proxy_btn.pack(side=tk.LEFT, padx=4)

        ttk.Button(ctrl, text="Clear captures",
                   command=self._clear_captures).pack(side=tk.LEFT, padx=4)
        ttk.Button(ctrl, text="Save all to file…",
                   command=self._save_captures).pack(side=tk.LEFT, padx=4)
        ttk.Button(ctrl, text="Load from file…",
                   command=self._load_captures).pack(side=tk.LEFT, padx=4)

        self._proxy_status = tk.StringVar(value="● Stopped")
        tk.Label(ctrl, textvariable=self._proxy_status,
                 font=("Consolas", 10, "bold"), fg="#ef233c").pack(side=tk.RIGHT, padx=8)

        # Filter
        ff = tk.Frame(f, bg="#1a1a2e")
        ff.pack(fill=tk.X, padx=12)
        self._char_only = tk.BooleanVar(value=False)
        tk.Checkbutton(ff, text="Show character payloads only (★)",
                       variable=self._char_only,
                       command=self._refresh_capture_list,
                       bg="#1a1a2e", fg="#e0e0e0",
                       selectcolor="#16213e",
                       font=("Consolas", 10)).pack(side=tk.LEFT)

        # List
        lf = ttk.LabelFrame(f, text=" Captured Payloads  (★ = likely character data) ")
        lf.pack(fill=tk.BOTH, expand=True, padx=12, pady=6)

        self._cap_listbox = tk.Listbox(lf, bg="#0d1b2a", fg="#e0e0e0",
                                       selectbackground="#00b4d8",
                                       selectforeground="#000",
                                       font=("Consolas", 9),
                                       activestyle="none")
        self._cap_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self._cap_listbox.bind("<<ListboxSelect>>", self._on_cap_select)

        sb = ttk.Scrollbar(lf, orient=tk.VERTICAL,
                           command=self._cap_listbox.yview)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self._cap_listbox.config(yscrollcommand=sb.set)

        # Preview
        pf = ttk.LabelFrame(f, text=" Payload Preview ")
        pf.pack(fill=tk.X, padx=12, pady=6)
        self._preview = scrolledtext.ScrolledText(
            pf, height=8, bg="#0d1b2a", fg="#e0e0e0",
            font=("Consolas", 8), state=tk.DISABLED
        )
        self._preview.pack(fill=tk.X)

        # Send to inject
        ttk.Button(f, text="Send selected to Inject →",
                   command=self._send_to_inject).pack(pady=6)

    # ── Inject tab ────────────────────────────────────────────────────────────

    def _build_inject_tab(self):
        f = self._tab_inject

        tk.Label(f, text=(
            "Selected payloads here will be served in place of the real\n"
            "Rockstar response when GTA Online initializes your character.\n"
            "Keep the proxy running with inject mode ON before launching GTA."
        ), justify=tk.LEFT).pack(padx=12, pady=8, anchor=tk.W)

        ctrl = tk.Frame(f, bg="#1a1a2e")
        ctrl.pack(fill=tk.X, padx=12, pady=4)

        self._inject_active = tk.BooleanVar(value=False)
        tk.Checkbutton(ctrl, text="  Inject mode ON",
                       variable=self._inject_active,
                       command=self._update_inject_mode,
                       bg="#1a1a2e", fg="#06d6a0",
                       selectcolor="#16213e",
                       font=("Consolas", 11, "bold")).pack(side=tk.LEFT)

        ttk.Button(ctrl, text="Clear inject queue",
                   command=self._clear_inject).pack(side=tk.LEFT, padx=12)

        lf = ttk.LabelFrame(f, text=" Inject Queue (host+path → payload) ")
        lf.pack(fill=tk.BOTH, expand=True, padx=12, pady=6)

        self._inject_listbox = tk.Listbox(lf, bg="#0d1b2a", fg="#06d6a0",
                                          selectbackground="#00b4d8",
                                          selectforeground="#000",
                                          font=("Consolas", 9),
                                          activestyle="none")
        self._inject_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        sb2 = ttk.Scrollbar(lf, orient=tk.VERTICAL,
                            command=self._inject_listbox.yview)
        sb2.pack(side=tk.RIGHT, fill=tk.Y)
        self._inject_listbox.config(yscrollcommand=sb2.set)

        tk.Label(f, text=(
            "TIP: Also run FSL (WINMM.dll) so Rockstar doesn't overwrite\n"
            "     your character with the server-side PC account data on save."
        ), fg="#ffd166", justify=tk.LEFT).pack(padx=12, pady=4, anchor=tk.W)

    # ── Log tab ───────────────────────────────────────────────────────────────

    def _build_log_tab(self):
        f = self._tab_log

        ctrl = tk.Frame(f, bg="#1a1a2e")
        ctrl.pack(fill=tk.X, padx=12, pady=6)
        ttk.Button(ctrl, text="Clear log",
                   command=self._clear_log).pack(side=tk.LEFT)

        self._log_box = scrolledtext.ScrolledText(
            f, bg="#0d1b2a", fg="#90e0ef",
            font=("Consolas", 9), state=tk.DISABLED
        )
        self._log_box.pack(fill=tk.BOTH, expand=True, padx=12, pady=4)

    # ── Actions ───────────────────────────────────────────────────────────────

    def _do_generate_ca(self):
        if not CRYPTO_OK:
            messagebox.showerror("Error", "cryptography package not installed.\nRun: pip install cryptography")
            return
        try:
            cert_pem, key_pem = generate_ca()
            CA_CERT.write_bytes(cert_pem)
            CA_KEY.write_bytes(key_pem)
            ok = install_ca_windows(CA_CERT)
            if ok:
                self._cert_status.set("✔  CA installed in Windows Trusted Root (user)")
                messagebox.showinfo("Done", "CA certificate installed successfully.\nYou can now start the proxy.")
            else:
                self._cert_status.set("⚠  CA generated but install may need admin")
                messagebox.showwarning(
                    "Manual install needed",
                    f"Auto-install failed. Please run this manually:\n\n"
                    f"certutil -addstore -user Root \"{CA_CERT}\""
                )
            self._load_ca()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _do_remove_ca(self):
        remove_ca_windows(CA_CERT)
        for p in (CA_CERT, CA_KEY):
            if p.exists():
                p.unlink()
        self._cert_status.set("◌  Certificate removed")
        self._cert_cache = None

    def _load_ca(self):
        if CA_CERT.exists() and CA_KEY.exists() and CRYPTO_OK:
            ca_cert_pem = CA_CERT.read_bytes()
            ca_key_pem  = CA_KEY.read_bytes()
            self._cert_cache = CertCache(ca_cert_pem, ca_key_pem)
            self._cert_status.set("✔  CA loaded and ready")

    def _toggle_proxy(self):
        if self._running:
            self._stop_proxy()
        else:
            self._start_proxy()

    def _start_proxy(self):
        if not self._cert_cache:
            messagebox.showerror("Error", "Generate & install the CA certificate first (Setup tab).")
            return
        try:
            port = int(self._port_var.get())
        except ValueError:
            messagebox.showerror("Error", "Invalid port number.")
            return

        self._proxy = MITMProxy(
            port        = port,
            cert_cache  = self._cert_cache,
            log_q       = self._log_q,
            capture_q   = self._capture_q,
            inject_mode = self._inject_active.get(),
            inject_map  = self._inject_map,
        )
        self._running = True
        self._proxy_thread = threading.Thread(target=self._proxy.start, daemon=True)
        self._proxy_thread.start()

        self._proxy_btn.config(text="■  Stop Proxy")
        self._proxy_status.set(f"● Running on :{port}")
        self._proxy_status_color("#06d6a0")
        self._status_var.set(f"Proxy running on 127.0.0.1:{port} — set Windows proxy now")

    def _stop_proxy(self):
        if self._proxy:
            self._proxy.stop()
        self._running = False
        self._proxy_btn.config(text="▶  Start Proxy")
        self._proxy_status.set("● Stopped")
        self._proxy_status_color("#ef233c")
        self._status_var.set("Proxy stopped.")

    def _proxy_status_color(self, color: str):
        # Find the label widget and update fg
        for w in self._tab_capture.winfo_children():
            if isinstance(w, tk.Frame):
                for c in w.winfo_children():
                    if isinstance(c, tk.Label) and "proxy_status" in str(c.cget("textvariable")):
                        c.configure(fg=color)

    def _update_inject_mode(self):
        if self._proxy:
            self._proxy.inject_mode = self._inject_active.get()
            mode = "ON" if self._inject_active.get() else "OFF"
            self._status_var.set(f"Inject mode {mode}")

    def _refresh_capture_list(self):
        self._cap_listbox.delete(0, tk.END)
        char_only = self._char_only.get()
        for cap in self._captures:
            if char_only and not cap.is_char:
                continue
            self._cap_listbox.insert(tk.END, cap.label)
            if cap.is_char:
                self._cap_listbox.itemconfig(tk.END, fg="#06d6a0")

    def _on_cap_select(self, _event=None):
        sel = self._cap_listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        visible = [c for c in self._captures
                   if not self._char_only.get() or c.is_char]
        if idx >= len(visible):
            return
        cap = visible[idx]
        self._preview.config(state=tk.NORMAL)
        self._preview.delete("1.0", tk.END)
        try:
            pretty = json.dumps(json.loads(cap.body), indent=2)
        except Exception:
            pretty = cap.body.decode("utf-8", errors="replace")
        self._preview.insert(tk.END, f"Host:   {cap.host}\n"
                                      f"Path:   {cap.path}\n"
                                      f"Method: {cap.method}\n"
                                      f"Status: {cap.status}\n"
                                      f"Time:   {cap.ts_str}\n"
                                      f"Char?:  {'YES ★' if cap.is_char else 'No'}\n"
                                      f"{'─'*60}\n{pretty}")
        self._preview.config(state=tk.DISABLED)

    def _send_to_inject(self):
        sel = self._cap_listbox.curselection()
        if not sel:
            messagebox.showinfo("Select a capture", "Click a captured payload first.")
            return
        idx = sel[0]
        visible = [c for c in self._captures
                   if not self._char_only.get() or c.is_char]
        if idx >= len(visible):
            return
        cap = visible[idx]
        key = f"{cap.host}{cap.path}"
        self._inject_map[key] = cap.body
        self._inject_listbox.insert(tk.END, f"{key}  ({len(cap.body)}b)")
        self._status_var.set(f"Added to inject queue: {key}")

    def _clear_inject(self):
        self._inject_map.clear()
        self._inject_listbox.delete(0, tk.END)

    def _clear_captures(self):
        self._captures.clear()
        self._refresh_capture_list()
        self._preview.config(state=tk.NORMAL)
        self._preview.delete("1.0", tk.END)
        self._preview.config(state=tk.DISABLED)

    def _save_captures(self):
        if not self._captures:
            messagebox.showinfo("No captures", "Nothing to save yet.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON", "*.json")],
            initialdir=str(CAPTURE_DIR),
            title="Save captures",
        )
        if not path:
            return
        data = [c.to_dict() for c in self._captures]
        Path(path).write_text(json.dumps(data, indent=2))
        self._status_var.set(f"Saved {len(self._captures)} captures to {path}")

    def _load_captures(self):
        path = filedialog.askopenfilename(
            filetypes=[("JSON", "*.json")],
            initialdir=str(CAPTURE_DIR),
            title="Load captures",
        )
        if not path:
            return
        try:
            data = json.loads(Path(path).read_text())
            loaded = [Capture.from_dict(d) for d in data]
            self._captures.extend(loaded)
            self._refresh_capture_list()
            self._status_var.set(f"Loaded {len(loaded)} captures from {path}")
        except Exception as e:
            messagebox.showerror("Load error", str(e))

    def _clear_log(self):
        self._log_box.config(state=tk.NORMAL)
        self._log_box.delete("1.0", tk.END)
        self._log_box.config(state=tk.DISABLED)

    # ── Queue polling ─────────────────────────────────────────────────────────

    def _poll_queues(self):
        # Log
        while not self._log_q.empty():
            msg = self._log_q.get_nowait()
            self._log_box.config(state=tk.NORMAL)
            self._log_box.insert(tk.END, msg + "\n")
            self._log_box.see(tk.END)
            self._log_box.config(state=tk.DISABLED)

        # Captures
        while not self._capture_q.empty():
            cap: Capture = self._capture_q.get_nowait()
            self._captures.append(cap)
            if self._char_only.get() and not cap.is_char:
                pass
            else:
                self._cap_listbox.insert(tk.END, cap.label)
                if cap.is_char:
                    self._cap_listbox.itemconfig(tk.END, fg="#06d6a0")
                    # Auto-switch to capture tab
                    self._nb.select(1)

        self.after(200, self._poll_queues)

    def on_close(self):
        if self._running:
            self._stop_proxy()
        self.destroy()


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    if not CRYPTO_OK:
        import tkinter.messagebox as mb
        root = tk.Tk()
        root.withdraw()
        mb.showerror(
            "Missing dependency",
            "The 'cryptography' package is required.\n\n"
            "Open a terminal and run:\n"
            "    pip install cryptography\n\n"
            "Then restart RSCTransfer."
        )
        root.destroy()
        return

    app = RSCTransferApp()
    app.protocol("WM_DELETE_WINDOW", app.on_close)
    app.mainloop()


if __name__ == "__main__":
    main()
