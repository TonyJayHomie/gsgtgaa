# RSCTransfer — GTA Online Character Transfer Tool

Captures your GTA Online character init payload via HTTPS proxy,
then injects it into a different Social Club account session.

## Requirements

- Windows 10 or 11
- Python 3.8+ (from python.org) **OR** just use the prebuilt RSCTransfer.exe
- `pip install cryptography`

## Quick Start

### Option A — Run from Python
```
pip install cryptography
python RSCTransfer.py
```

### Option B — Build .exe yourself
```
pip install cryptography pyinstaller
build_exe.bat
```
Then run `dist\RSCTransfer.exe`

---

## How To Use

### Step 1 — Setup tab
1. Click **Generate + Install CA**
   - Installs a root certificate into your Windows personal cert store
   - This lets the proxy read GTA's HTTPS traffic
   - You can remove it any time with "Remove CA"

### Step 2 — Start Proxy (Capture tab)
1. Click **▶ Start Proxy** (default port 8080)
2. Go to **Windows Settings → Network → Proxy → Manual proxy setup**
   - Turn ON, Address: `127.0.0.1`, Port: `8080`

### Step 3 — Capture your Xbox character
1. Sign into Rockstar Social Club with your **Xbox account**
2. Launch GTA V → Enter GTA Online → Wait for full load into a session
3. Watch the Capture tab — starred (★) items are likely character payloads
4. Character init packets usually appear within 30-60 seconds of session load

### Step 4 — Send to Inject
1. Click the ★ starred capture(s)
2. Click **Send selected to Inject →**
3. Sign OUT of the Xbox Social Club account

### Step 5 — Inject into PC account
1. Sign into Rockstar Social Club with your **PC account**
2. Switch to **Inject tab**
3. Check **Inject mode ON**
4. Make sure proxy is still running
5. Launch GTA V → Enter GTA Online
6. The proxy serves your Xbox character data instead of the real PC response

### Step 6 — Combine with FSL
Run **FSL (WINMM.dll)** at the same time so that save operations
go to local disk instead of Rockstar's servers. This prevents
Rockstar from overwriting the injected character with the PC
account's server-side blank character on the next save cycle.

---

## Known Limitations

- **Certificate Pinning**: If Rockstar has pinned certificates in the
  GTA Enhanced client, the proxy cannot intercept those specific calls.
  The capture list will show traffic for non-pinned endpoints only.
  In testing, most GTA Online character init calls are NOT pinned.

- **Server-side state**: The injection works at the client level.
  Rockstar's servers still see your PC account. FSL is essential to
  prevent the server-side state from overwriting the injected data.

- **Session validation**: Some character properties (properties owned,
  vehicles in garage) are validated server-side. These may not carry
  over purely from client-level injection. Money is easiest to set
  via FSL `100M` cheat regardless.

---

## Certificate Management

The CA cert is stored at:
```
%APPDATA%\RSCTransfer\certs\RSCTransfer_CA.crt
```

To manually remove from Windows cert store:
```
certutil -delstore -user Root RSCTransfer
```

---

## Data Location

All captures saved to: `%APPDATA%\RSCTransfer\captures\`
