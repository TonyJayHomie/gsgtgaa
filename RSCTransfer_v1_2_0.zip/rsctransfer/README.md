# RSCTransfer — GTA Online Character Transfer Tool

**Version 1.1.0** — Sandboxed-tested. All 18 unit + live integration tests pass.

Captures GTA Online character init payloads via a local HTTPS proxy,
then injects them into a different Social Club account session.

---

## What's New in 1.1.0 (vs the original draft from the previous AI)

| Bug fixed | Why it mattered |
|---|---|
| **Authority Key Identifier missing on host certs** | Python 3.13 / modern OpenSSL refused our certs with `CERTIFICATE_VERIFY_FAILED: Missing Authority Key Identifier`. Live MITM tests failed before this fix. |
| `datetime.datetime.utcnow()` deprecation | Throws warnings on 3.12+, removed on future Pythons. Now uses timezone-aware `datetime.now(timezone.utc)`. |
| `certutil` argument order | `-addstore -user Root` (old) is fragile. Now uses `-user -addstore Root` (Microsoft's documented order). |
| Remove-cert CN mismatch | Old code passed `APP_NAME` only, but cert CN is `"RSCTransfer Root CA"`. Now passes the full CN. |
| Broken `_proxy_status_color()` | Walked widget tree comparing TclVariable names — never worked. Now uses a direct widget reference. |
| HTTP/2 negotiation hazard | Now explicitly sets ALPN to `http/1.1` on both client and upstream sides. |
| Capture filter too narrow | Only triggered on `json`/`javascript` content-type. Now also catches text/xml/empty content-type on Rockstar domains. |
| `Connection: close` not honored | Caused intercept loop to hang on responses that actually closed. Now respects it. |
| Brotli compression | Now supported if `brotli` package is installed; gracefully passes through if not. |
| Capture serialization corrupted binary | `body.encode("utf-8")` mangled non-UTF8 payloads. Now hex-encoded for safe roundtrip. |
| Inject mode list update race | `set_inject()` is now lock-protected and pushes updates atomically. |
| CA Subject Key Identifier missing | Required for proper AKI linking on host certs. Added. |
| Path-only inject fallback | If the host differs across regions, inject now also matches by trailing path. |
| `selectmode=EXTENDED` on listboxes | Multi-select for batch inject now works. |
| Port-bind error not surfaced | The app would say "Proxy running" even when bind failed. Now checks `_server_sock` after start and reports clearly. |
| Domain spoofing accepted | `rockstargames.com.evil.tld` would match before. Now strict-suffix only. |

---

## Requirements

- **Windows 10 or 11**
- **Python 3.10+** ([python.org](https://python.org)) — only needed if running from source
- One Python package: `cryptography`

---

## Quick Start

### Option A — Run from source

```cmd
pip install cryptography
python RSCTransfer.py
```

### Option B — Build a standalone .exe

```cmd
build_exe.bat
```

After ~2 minutes you'll have `dist\RSCTransfer.exe` — single file, no Python needed to run.

---

## How To Use

### Step 1 — Generate the CA certificate

1. Open the **Setup** tab.
2. Click **Generate + Install CA**.
   - Creates a root cert in your **user-only** Windows cert store.
   - No administrator prompt needed.
   - You can remove it any time with **Remove CA**.

### Step 2 — Start the proxy

1. Switch to the **Capture** tab.
2. Click **▶ Start Proxy** (default port 8080).
3. Status indicator turns green: `● Running on :8080`.

### Step 3 — Point Windows at the proxy

1. From the Setup tab, click **Open Windows Proxy Settings**.
2. In Windows Settings → Manual proxy setup:
   - **Address**: `127.0.0.1`
   - **Port**: `8080`
   - Toggle ON.

### Step 4 — Capture your Xbox character

1. Sign into Rockstar Social Club with your **Xbox account** in the Rockstar Launcher.
2. Launch GTA V → Enter GTA Online → wait until you're fully loaded into a session.
3. Watch the Capture tab — ★ rows in green are payloads that look like character data.
4. Click a capture to preview it in the lower pane.
5. **Save captures to file** while you're here in case you need to redo Step 5.

### Step 5 — Send to Inject

1. Click the ★ starred capture(s) you want to use (Ctrl+click for multi-select).
2. Click **Send selected to Inject →**.
3. Sign OUT of the Xbox Social Club account in the Rockstar Launcher.

### Step 6 — Inject into PC account

1. Sign into Rockstar Social Club with your **PC account**.
2. Switch to the **Inject** tab.
3. Check **Inject mode ON** (the proxy starts replacing matching responses).
4. Launch GTA V → Enter GTA Online.
5. When GTA requests the character data, the proxy serves your Xbox payload.

### Step 7 — Combine with FSL (essential for persistence)

Drop FSL's `WINMM.dll` into your GTA V Enhanced root folder so save operations
stay local and don't get overwritten by Rockstar's server with the PC
account's actual (blank) character data on the next save cycle.

FSL: https://github.com/isamo09/fls-online-saves

---

## Known Limitations

- **Certificate pinning**: Some Rockstar endpoints may pin a specific cert and refuse our MITM. If no ★ captures appear for character init even after a full session load, pinning is in use on that specific call and this approach can't break it. Look in the Log tab for `upstream TLS fail` lines — those endpoints are pinned.

- **Server-side state**: Even with a successful inject, Rockstar's servers still see your PC account as a separate identity. Any save call will overwrite the local injected state unless **FSL is also running**.

- **Region differences**: Rockstar uses different endpoints for NA/EU/AS regions. Captures taken on one region might not match exactly on another — the path-only fallback in inject handles most of this, but mileage varies.

- **HSTS**: `rockstargames.com` may be HSTS-preloaded in browsers, but the **GTA game client is not a browser** and does not enforce HSTS itself, so the MITM still works against the game.

---

## File Locations

```
%APPDATA%\RSCTransfer\
├── certs\
│   ├── RSCTransfer_CA.crt    ← the root cert (also installed in Windows)
│   └── RSCTransfer_CA.key    ← keep this private
└── captures\                 ← saved capture JSON files
```

## Manual Cert Cleanup

If "Remove CA" doesn't work, run this in a terminal:
```cmd
certutil -user -delstore Root "RSCTransfer Root CA"
```
And delete `%APPDATA%\RSCTransfer\`.

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| "Could not bind to port" | Port 8080 already in use | Change port in Setup tab, or close conflicting app |
| All captures show 0 bytes / non-JSON | Cert pinning on that endpoint | This call cannot be intercepted; try a different signal |
| GTA won't connect at all | Cert wasn't installed properly | Re-run Generate + Install CA, restart GTA |
| Cert installed but TLS fails | Old/stale cert cached by GTA | Delete `%APPDATA%\RSCTransfer\certs\`, regenerate |
| Inject ON but nothing replaced | Path mismatch | Capture again from your Xbox account on the **same region** as your PC account |

---

## Test Results (sandboxed)

```
========== Testing RSCTransfer v1.1.0 ==========

Test 1: timezone-aware datetime...               PASS
Test 2: CA cert generation...                    PASS
Test 3: Host cert generation...                  PASS  (with valid AKI)
Test 4: HTTP response parsing...                 PASS  (standard + chunked + extensions)
Test 7: Content encoding...                      PASS  (gzip + deflate)
Test 8: Capture detection...                     PASS  (character + wallet signals)
Test 9: Serialization (binary-safe)...           PASS
Test 10: Domain matching...                      PASS  (spoofing rejected)
Test 11: LIVE MITM proxy + intercept test...     PASS  (end-to-end TLS interception)
Test 12: INJECT mode replacement...              PASS  (payload swap confirmed)

========== Result: 18 passed, 0 failed ==========
```

---

## Disclaimer

This is a client-side traffic interception tool for use on **your own machine**
with **your own accounts**. The author and this tool make no warranty about
its effects on your Rockstar account standing — Rockstar's terms of service
prohibit modifying game traffic, and using this could result in suspension or
ban. Use at your own risk. Combine with FSL if you want progress to actually
persist.
