@echo off
setlocal
echo ============================================
echo  RSCTransfer - Build EXE
echo ============================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found in PATH.
    echo Install Python 3.10+ from https://python.org
    echo Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('python --version') do echo Detected: %%v

echo.
echo Installing dependencies (cryptography, pyinstaller)...
python -m pip install --upgrade --quiet cryptography pyinstaller
if errorlevel 1 (
    echo ERROR: pip install failed. Check your internet connection.
    pause
    exit /b 1
)

if exist build rmdir /s /q build
if exist dist  rmdir /s /q dist
if exist RSCTransfer.spec del RSCTransfer.spec

echo.
echo Building RSCTransfer.exe (this takes 1-2 minutes)...
echo.
python -m PyInstaller ^
    --onefile ^
    --windowed ^
    --name RSCTransfer ^
    --clean ^
    --noconfirm ^
    --hidden-import cryptography ^
    --hidden-import cryptography.hazmat ^
    --hidden-import cryptography.hazmat.primitives ^
    --hidden-import cryptography.hazmat.primitives.asymmetric ^
    --hidden-import cryptography.hazmat.primitives.asymmetric.rsa ^
    --hidden-import cryptography.hazmat.primitives.hashes ^
    --hidden-import cryptography.hazmat.primitives.serialization ^
    --hidden-import cryptography.hazmat.backends ^
    --hidden-import cryptography.x509 ^
    --hidden-import cryptography.x509.oid ^
    RSCTransfer.py

echo.
if exist dist\RSCTransfer.exe (
    echo ============================================
    echo  SUCCESS:  dist\RSCTransfer.exe is ready
    echo ============================================
    echo.
    echo You can now double-click dist\RSCTransfer.exe to run the app.
) else (
    echo ============================================
    echo  FAILED:  Check the output above for errors
    echo ============================================
)
echo.
pause
endlocal
