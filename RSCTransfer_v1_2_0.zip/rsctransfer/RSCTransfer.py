"""
RSCTransfer - GTA Online Character Transfer Tool
=================================================
Captures GTA Online character init data via a local HTTPS MITM proxy,
then injects it into a different Social Club account session.

Requirements:
    Python 3.8+ (3.11+ recommended)
    pip install cryptography

Usage:
    python RSCTransfer.py
    (or double-click RSCTransfer.exe after building with build_exe.bat)

How it works:
    1. Generates a root CA cert and installs it into your Windows user
       trusted root store (no admin required).
    2. Runs a local HTTPS MITM proxy (default port 8080).
    3. You set Windows proxy to 127.0.0.1:8080.
    4. Launch GTA Online with Account A (Xbox / source account) — proxy
       captures the Rockstar character initialization payloads.
    5. Switch to Account B (PC / target account), proxy injects the saved
       payloads so GTA receives Account A's character data.
    6. Run alongside FSL (WINMM.dll) so saves stay local and don't get
       overwritten by Rockstar's server state.

CAVEATS:
    - Rockstar may use certificate pinning on some endpoints. If a star
      (★) capture never appears for character data, pinning is in use
      on that specific call and this approach cannot intercept it.
    - This is a client-side tool. Server-side state remains tied to your
      actual Social Club account. FSL is required for the changes to
      persist locally.
    - Run as Administrator if you see "permission denied" on port bind.

Version: 1.2.0  (adds Xbox console proxy support — LAN IP display, CA cert HTTP
              endpoint for Xbox Edge install, Export-to-USB button, Xbox proxy
              step-by-step instructions in Setup tab)
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog
import threading
import socket
import ssl
import json
import os
import re
import gzip
import zlib
import time
import datetime
import queue
import select
import subprocess
import tempfile
from pathlib import Path
from typing import Optional, Dict, List, Tuple

# ── cryptography ──────────────────────────────────────────────────────────────
try:
    from cryptography import x509
    from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.hazmat.backends import default_backend
    CRYPTO_OK = True
except ImportError:
    CRYPTO_OK = False


# ── Constants ─────────────────────────────────────────────────────────────────
APP_NAME    = "RSCTransfer"
APP_VER     = "1.2.0"
APP_CN      = f"{APP_NAME} Root CA"
DATA_DIR    = Path(os.environ.get("APPDATA", str(Path.home() / ".rsctransfer"))) / APP_NAME
CERT_DIR    = DATA_DIR / "certs"
CAPTURE_DIR = DATA_DIR / "captures"
CA_CERT     = CERT_DIR / "RSCTransfer_CA.crt"
CA_KEY      = CERT_DIR / "RSCTransfer_CA.key"
DEFAULT_PORT = 8080

RSC_DOMAIN_SUFFIXES = (
    "rockstargames.com",
    "rockstargames.net",
    "socialclub.rockstargames.com",
)

CHAR_SIGNALS = (
    "characterdata", "mpchars", "chardata", "characterid",
    "charindex", "rankdata", "statsdata", "charappearance",
    "mpcharinfo", "gtavmpchar", "wallet", "bank_cash",
    "money", "mpply", "char_appearance", "mp_character",
)


def get_local_ips() -> List[Tuple[str, str]]:
    """Return [(label, ip), ...] for non-loopback IPv4 addresses on this machine."""
    seen: List[str] = []
    result: List[Tuple[str, str]] = []
    # Method 1: UDP connect trick — picks the routing-preferred interface first
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            if ip and not ip.startswith("127.") and ip not in seen:
                seen.append(ip)
                result.append(("Primary", ip))
    except Exception:
        pass
    # Method 2: hostname resolution — catches additional adapters
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None):
            if info[0] == socket.AF_INET:
                ip = info[4][0]
                if not ip.startswith("127.") and ip not in seen:
                    seen.append(ip)
                    result.append(("Adapter", ip))
    except Exception:
        pass
    return result or [("Unknown", "0.0.0.0")]


# ── timezone-aware UTC (Python 3.12+ deprecates utcnow) ────────────────────────

def _utcnow() -> datetime.datetime:
    try:
        return datetime.datetime.now(datetime.timezone.utc)
    except Exception:
        return datetime.datetime.utcnow()


# ── Certificate helpers ───────────────────────────────────────────────────────

def _make_name(cn: str) -> "x509.Name":
    return x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "US"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, APP_NAME),
        x509.NameAttribute(NameOID.COMMON_NAME, cn),
    ])


def generate_ca() -> Tuple[bytes, bytes]:
    """Generate root CA key + self-signed cert. Returns (cert_pem, key_pem)."""
    key = rsa.generate_private_key(
        public_exponent=65537, key_size=2048, backend=default_backend()
    )
    now = _utcnow()
    cert = (
        x509.CertificateBuilder()
        .subject_name(_make_name(APP_CN))
        .issuer_name(_make_name(APP_CN))
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + datetime.timedelta(days=3650))
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .add_extension(
            x509.KeyUsage(
                digital_signature=True, key_cert_sign=True, crl_sign=True,
                content_commitment=False, key_encipherment=False,
                data_encipherment=False, key_agreement=False,
                encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(
            x509.SubjectKeyIdentifier.from_public_key(key.public_key()),
            critical=False,
        )
        .sign(key, hashes.SHA256(), default_backend())
    )
    return (
        cert.public_bytes(serialization.Encoding.PEM),
        key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption(),
        ),
    )


def generate_host_cert(hostname: str, ca_cert_pem: bytes, ca_key_pem: bytes) -> Tuple[bytes, bytes]:
    """Generate a host cert signed by our CA, with proper SKI/AKI linkage."""
    ca_cert = x509.load_pem_x509_certificate(ca_cert_pem, default_backend())
    ca_key_obj = serialization.load_pem_private_key(ca_key_pem, password=None, backend=default_backend())

    key = rsa.generate_private_key(
        public_exponent=65537, key_size=2048, backend=default_backend()
    )
    now = _utcnow()

    san_list: List[x509.GeneralName] = [x509.DNSName(hostname)]
    if hostname.startswith("*."):
        san_list.append(x509.DNSName(hostname[2:]))

    builder = (
        x509.CertificateBuilder()
        .subject_name(_make_name(hostname))
        .issuer_name(ca_cert.subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + datetime.timedelta(days=365))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(x509.SubjectAlternativeName(san_list), critical=False)
        .add_extension(
            x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False
        )
        .add_extension(
            x509.SubjectKeyIdentifier.from_public_key(key.public_key()),
            critical=False,
        )
    )

    # AKI from the CA's SKI — required by strict TLS validators (Python 3.13+)
    try:
        ski_ext = ca_cert.extensions.get_extension_for_class(x509.SubjectKeyIdentifier)
        aki = x509.AuthorityKeyIdentifier.from_issuer_subject_key_identifier(ski_ext.value)
    except x509.ExtensionNotFound:
        aki = x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_cert.public_key())
    builder = builder.add_extension(aki, critical=False)

    cert = builder.sign(ca_key_obj, hashes.SHA256(), default_backend())
    return (
        cert.public_bytes(serialization.Encoding.PEM),
        key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption(),
        ),
    )


def install_ca_windows(cert_path: Path) -> Tuple[bool, str]:
    """Import the CA cert into Windows Trusted Root store (no admin needed for -user)."""
    if os.name != "nt":
        return False, "Not Windows — manual install required."
    cmd = ["certutil", "-user", "-addstore", "Root", str(cert_path)]
    try:
        r = subprocess.run(
            cmd, capture_output=True, timeout=30,
            creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0,
        )
        out = (r.stdout or b"").decode("utf-8", errors="replace") + (r.stderr or b"").decode("utf-8", errors="replace")
        return r.returncode == 0, out
    except FileNotFoundError:
        return False, "certutil.exe not found in PATH."
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def remove_ca_windows() -> Tuple[bool, str]:
    """Remove the CA cert from Windows Trusted Root store by CN."""
    if os.name != "nt":
        return False, "Not Windows."
    cmd = ["certutil", "-user", "-delstore", "Root", APP_CN]
    try:
        r = subprocess.run(
            cmd, capture_output=True, timeout=30,
            creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0,
        )
        out = (r.stdout or b"").decode("utf-8", errors="replace") + (r.stderr or b"").decode("utf-8", errors="replace")
        return r.returncode == 0, out
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


class CertCache:
    def __init__(self, ca_cert_pem: bytes, ca_key_pem: bytes):
        self._ca_cert = ca_cert_pem
        self._ca_key  = ca_key_pem
        self._cache: Dict[str, Tuple[bytes, bytes]] = {}
        self._lock = threading.Lock()

    def get(self, hostname: str) -> Tuple[bytes, bytes]:
        with self._lock:
            if hostname not in self._cache:
                self._cache[hostname] = generate_host_cert(hostname, self._ca_cert, self._ca_key)
            return self._cache[hostname]


# ── HTTP body decode ──────────────────────────────────────────────────────────

def decode_body(raw: bytes, encoding: str) -> bytes:
    enc = (encoding or "").lower().strip()
    try:
        if enc == "gzip":
            return gzip.decompress(raw)
        if enc in ("deflate", "zlib"):
            try:
                return zlib.decompress(raw)
            except zlib.error:
                return zlib.decompress(raw, -zlib.MAX_WBITS)
        if enc == "br":
            try:
                import brotli  # type: ignore
                return brotli.decompress(raw)
            except ImportError:
                return raw
    except Exception:
        pass
    return raw


def parse_http_response(data: bytes) -> Tuple[int, Dict[str, str], bytes]:
    try:
        header_end = data.index(b"\r\n\r\n")
    except ValueError:
        return 0, {}, data

    header_part = data[:header_end].decode("utf-8", errors="replace")
    body_raw    = data[header_end + 4:]

    lines = header_part.split("\r\n")
    try:
        status = int(lines[0].split()[1]) if lines and len(lines[0].split()) >= 2 else 0
    except (ValueError, IndexError):
        status = 0
    headers: Dict[str, str] = {}
    for line in lines[1:]:
        if ":" in line:
            k, _, v = line.partition(":")
            headers[k.strip().lower()] = v.strip()

    if headers.get("transfer-encoding", "").lower() == "chunked":
        body_raw = _dechunk(body_raw)

    body = decode_body(body_raw, headers.get("content-encoding", ""))
    return status, headers, body


def _dechunk(data: bytes) -> bytes:
    out = b""
    while data:
        try:
            end = data.index(b"\r\n")
        except ValueError:
            break
        size_str = data[:end]
        try:
            size = int(size_str.split(b";")[0], 16)
        except ValueError:
            break
        if size == 0:
            break
        if end + 2 + size > len(data):
            break
        out  += data[end + 2: end + 2 + size]
        data  = data[end + 2 + size + 2:]
    return out


def read_full_response(sock: ssl.SSLSocket, timeout_total: float = 15.0) -> bytes:
    sock.settimeout(2.0)
    data = b""
    deadline = time.time() + timeout_total

    while b"\r\n\r\n" not in data:
        if time.time() > deadline:
            return data
        try:
            chunk = sock.recv(8192)
        except socket.timeout:
            continue
        except Exception:
            return data
        if not chunk:
            return data
        data += chunk

    header_end = data.index(b"\r\n\r\n")
    headers_raw = data[:header_end].decode("utf-8", errors="replace")
    cl_match = re.search(r"content-length:\s*(\d+)", headers_raw, re.I)
    te_match = re.search(r"transfer-encoding:\s*chunked", headers_raw, re.I)

    if cl_match:
        target_total = header_end + 4 + int(cl_match.group(1))
        while len(data) < target_total and time.time() < deadline:
            try:
                chunk = sock.recv(8192)
            except socket.timeout:
                continue
            except Exception:
                break
            if not chunk:
                break
            data += chunk
        return data

    if te_match:
        while b"\r\n0\r\n\r\n" not in data and b"\n0\r\n\r\n" not in data:
            if time.time() > deadline:
                break
            try:
                chunk = sock.recv(8192)
            except socket.timeout:
                continue
            except Exception:
                break
            if not chunk:
                break
            data += chunk
        return data

    while time.time() < deadline:
        try:
            chunk = sock.recv(8192)
        except socket.timeout:
            continue
        except Exception:
            break
        if not chunk:
            break
        data += chunk
    return data


def read_full_request(sock: ssl.SSLSocket, timeout_total: float = 15.0) -> bytes:
    sock.settimeout(2.0)
    data = b""
    deadline = time.time() + timeout_total

    while b"\r\n\r\n" not in data:
        if time.time() > deadline:
            return data
        try:
            chunk = sock.recv(8192)
        except socket.timeout:
            continue
        except Exception:
            return data
        if not chunk:
            return data
        data += chunk

    header_end = data.index(b"\r\n\r\n")
    headers_raw = data[:header_end].decode("utf-8", errors="replace")
    cl_match = re.search(r"content-length:\s*(\d+)", headers_raw, re.I)

    if cl_match:
        target_total = header_end + 4 + int(cl_match.group(1))
        while len(data) < target_total and time.time() < deadline:
            try:
                chunk = sock.recv(8192)
            except socket.timeout:
                continue
            except Exception:
                break
            if not chunk:
                break
            data += chunk

    return data


# ── Capture record ────────────────────────────────────────────────────────────

class Capture:
    def __init__(self, host: str, path: str, method: str, status: int,
                 body: bytes, content_type: str, ts: float):
        self.host    = host
        self.path    = path
        self.method  = method
        self.status  = status
        self.body    = body
        self.content_type = content_type
        self.ts      = ts
        self.ts_str  = datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
        self.is_char = self._detect()
        self.label   = f"[{'★' if self.is_char else ' '}] {method} {host}{path} ({status})  {len(body)}b"

    def _detect(self) -> bool:
        try:
            txt = self.body.decode("utf-8", errors="replace").lower()
            return any(sig in txt for sig in CHAR_SIGNALS)
        except Exception:
            return False

    def to_dict(self) -> dict:
        return {
            "host": self.host, "path": self.path, "method": self.method,
            "status": self.status,
            "body_b64": self.body.hex(),
            "content_type": self.content_type,
            "ts": self.ts, "is_char": self.is_char,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Capture":
        body = bytes.fromhex(d["body_b64"]) if "body_b64" in d else d.get("body", "").encode("utf-8")
        return cls(
            host=d["host"], path=d["path"], method=d["method"],
            status=d["status"], body=body,
            content_type=d.get("content_type", "application/json"),
            ts=d["ts"],
        )


# ── MITM Proxy ────────────────────────────────────────────────────────────────

class MITMProxy:
    def __init__(self, port: int, cert_cache: CertCache,
                 log_q: queue.Queue, capture_q: queue.Queue,
                 inject_mode: bool = False,
                 inject_map: Optional[Dict[str, "Capture"]] = None):
        self.port        = port
        self.cert_cache  = cert_cache
        self.log_q       = log_q
        self.capture_q   = capture_q
        self.inject_mode = inject_mode
        self.inject_map  = inject_map if inject_map is not None else {}
        self._server_sock: Optional[socket.socket] = None
        self._running    = False
        self._lock       = threading.Lock()

    def start(self):
        try:
            self._server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._server_sock.bind(("0.0.0.0", self.port))
            self._server_sock.listen(100)
            self._server_sock.settimeout(1.0)
        except OSError as e:
            self._log(f"[!] Could not bind port {self.port}: {e}")
            self._server_sock = None
            return

        self._running = True
        self._log(f"Proxy listening on 0.0.0.0:{self.port}")
        while self._running:
            try:
                client_sock, addr = self._server_sock.accept()
                t = threading.Thread(target=self._handle, args=(client_sock,), daemon=True)
                t.start()
            except socket.timeout:
                continue
            except OSError:
                break
        self._log("Proxy stopped.")

    def stop(self):
        self._running = False
        if self._server_sock:
            try:
                self._server_sock.close()
            except Exception:
                pass
            self._server_sock = None

    def set_inject(self, mode: bool, mapping: Optional[Dict[str, "Capture"]] = None):
        with self._lock:
            self.inject_mode = mode
            if mapping is not None:
                self.inject_map = mapping

    def _log(self, msg: str):
        try:
            self.log_q.put_nowait(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] {msg}")
        except queue.Full:
            pass

    def _is_rsc(self, host: str) -> bool:
        host = host.lower()
        return any(host == sfx or host.endswith("." + sfx) for sfx in RSC_DOMAIN_SUFFIXES)

    def _handle(self, client_sock: socket.socket):
        try:
            client_sock.settimeout(15)
            data = b""
            while b"\r\n\r\n" not in data:
                try:
                    chunk = client_sock.recv(4096)
                except (socket.timeout, OSError):
                    return
                if not chunk:
                    return
                data += chunk

            first_line = data.split(b"\r\n", 1)[0].decode("utf-8", errors="replace")
            parts = first_line.split()
            if len(parts) < 3:
                return

            method = parts[0].upper()
            if method == "CONNECT":
                self._handle_connect(client_sock, parts[1])
            else:
                self._forward_plain(client_sock, data)
        except Exception as e:
            self._log(f"handle error: {type(e).__name__}: {e}")
        finally:
            try:
                client_sock.close()
            except Exception:
                pass

    def _handle_connect(self, client_sock: socket.socket, host_port: str):
        if ":" in host_port:
            host, _, port_s = host_port.rpartition(":")
            try:
                port = int(port_s)
            except ValueError:
                port = 443
        else:
            host, port = host_port, 443

        try:
            client_sock.sendall(b"HTTP/1.1 200 Connection established\r\n\r\n")
        except OSError:
            return

        if not self._is_rsc(host):
            self._tunnel(client_sock, host, port)
            return

        cert_pem, key_pem = self.cert_cache.get(host)
        cert_file = key_file = None
        try:
            cert_file = tempfile.NamedTemporaryFile(delete=False, suffix=".pem")
            cert_file.write(cert_pem); cert_file.close()
            key_file = tempfile.NamedTemporaryFile(delete=False, suffix=".pem")
            key_file.write(key_pem); key_file.close()

            ctx_srv = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ctx_srv.load_cert_chain(cert_file.name, key_file.name)
            try:
                ctx_srv.set_alpn_protocols(["http/1.1"])
            except (NotImplementedError, AttributeError):
                pass

            try:
                client_tls = ctx_srv.wrap_socket(client_sock, server_side=True)
            except ssl.SSLError as e:
                self._log(f"client TLS handshake fail {host}: {e}")
                return

            try:
                raw_server = socket.create_connection((host, port), timeout=10)
            except OSError as e:
                self._log(f"upstream connect fail {host}:{port}: {e}")
                try: client_tls.close()
                except Exception: pass
                return

            ctx_cli = ssl.create_default_context()
            try:
                ctx_cli.set_alpn_protocols(["http/1.1"])
            except (NotImplementedError, AttributeError):
                pass

            try:
                server_tls = ctx_cli.wrap_socket(raw_server, server_hostname=host)
            except ssl.SSLError as e:
                self._log(f"upstream TLS fail {host}: {e}  (cert pinning or chain issue)")
                try: client_tls.close()
                except Exception: pass
                try: raw_server.close()
                except Exception: pass
                return

            try:
                self._intercept_loop(client_tls, server_tls, host)
            finally:
                try: client_tls.close()
                except Exception: pass
                try: server_tls.close()
                except Exception: pass
        finally:
            for f in (cert_file, key_file):
                if f is not None:
                    try: os.unlink(f.name)
                    except Exception: pass

    def _intercept_loop(self, client: ssl.SSLSocket, server: ssl.SSLSocket, host: str):
        try:
            while True:
                req_data = read_full_request(client, timeout_total=20.0)
                if not req_data:
                    return

                first_line = req_data.split(b"\r\n", 1)[0].decode("utf-8", errors="replace")
                parts = first_line.split()
                method = parts[0] if parts else "GET"
                path   = parts[1] if len(parts) > 1 else "/"

                with self._lock:
                    inject_mode = self.inject_mode
                    inject_map  = dict(self.inject_map)

                key = f"{host}{path}"
                injected: Optional["Capture"] = None
                if inject_mode:
                    if key in inject_map:
                        injected = inject_map[key]
                    else:
                        for k, v in inject_map.items():
                            if k.endswith(path):
                                injected = v
                                break

                if injected is not None:
                    ct = injected.content_type or "application/json"
                    body = injected.body
                    resp = (
                        b"HTTP/1.1 200 OK\r\n"
                        b"Content-Type: " + ct.encode("ascii", errors="replace") + b"\r\n"
                        b"Content-Length: " + str(len(body)).encode() + b"\r\n"
                        b"Cache-Control: no-store\r\n"
                        b"Connection: close\r\n\r\n"
                    ) + body
                    try:
                        client.sendall(resp)
                    except OSError:
                        pass
                    self._log(f"★ INJECTED → {host}{path}  ({len(body)}b)")
                    return

                try:
                    server.sendall(req_data)
                except OSError as e:
                    self._log(f"upstream send fail {host}: {e}")
                    return

                resp_data = read_full_response(server, timeout_total=20.0)
                if not resp_data:
                    return

                try:
                    client.sendall(resp_data)
                except OSError:
                    return

                status, headers, body = parse_http_response(resp_data)
                ct = headers.get("content-type", "")
                if (status > 0 and
                    ("json" in ct or "javascript" in ct or "text" in ct or "xml" in ct or not ct)):
                    cap = Capture(host, path, method, status, body, ct, time.time())
                    self._log(f"{'★ CHAR ' if cap.is_char else 'capture'} {method} {host}{path} → {status} ({len(body)}b)")
                    try:
                        self.capture_q.put_nowait(cap)
                    except queue.Full:
                        pass

                conn_hdr = headers.get("connection", "").lower()
                if conn_hdr == "close":
                    return

        except Exception as e:
            self._log(f"intercept loop on {host}: {type(e).__name__}: {e}")

    def _tunnel(self, client_sock: socket.socket, host: str, port: int):
        try:
            server_sock = socket.create_connection((host, port), timeout=10)
        except OSError:
            return

        socks = [client_sock, server_sock]
        try:
            while True:
                try:
                    readable, _, errored = select.select(socks, [], socks, 10)
                except (OSError, ValueError):
                    return
                if errored or not readable:
                    return
                for s in readable:
                    other = server_sock if s is client_sock else client_sock
                    try:
                        data = s.recv(8192)
                    except OSError:
                        return
                    if not data:
                        return
                    try:
                        other.sendall(data)
                    except OSError:
                        return
        finally:
            try: server_sock.close()
            except Exception: pass

    def _forward_plain(self, client_sock: socket.socket, data: bytes):
        # ── serve CA cert locally so Xbox Edge can download and install it ──────
        first_line = data.split(b"\r\n", 1)[0].decode("utf-8", errors="replace")
        if re.search(r"GET\s+/ca\.crt(\s|$)", first_line, re.I):
            if CA_CERT.exists():
                cert_bytes = CA_CERT.read_bytes()
                resp = (
                    b"HTTP/1.1 200 OK\r\n"
                    b"Content-Type: application/x-x509-ca-cert\r\n"
                    b"Content-Disposition: attachment; filename=\"RSCTransfer_CA.crt\"\r\n"
                    b"Content-Length: " + str(len(cert_bytes)).encode() + b"\r\n"
                    b"Cache-Control: no-store\r\n"
                    b"Connection: close\r\n\r\n"
                ) + cert_bytes
            else:
                resp = b"HTTP/1.1 404 Not Found\r\nContent-Length: 13\r\nConnection: close\r\n\r\nCA not found."
            try:
                client_sock.sendall(resp)
            except OSError:
                pass
            self._log("Served CA cert to client (Xbox cert install)")
            return

        match = re.search(rb"Host:\s*([^\r\n]+)", data, re.I)
        if not match:
            return
        host_hdr = match.group(1).decode("utf-8", errors="replace").strip()
        host = host_hdr.split(":")[0]
        try:
            port = int(host_hdr.split(":")[1]) if ":" in host_hdr else 80
        except ValueError:
            port = 80

        server = None
        try:
            server = socket.create_connection((host, port), timeout=10)
            server.sendall(data)
            server.settimeout(5)
            resp = b""
            while True:
                try:
                    chunk = server.recv(8192)
                except (socket.timeout, OSError):
                    break
                if not chunk:
                    break
                resp += chunk
            if resp:
                try: client_sock.sendall(resp)
                except OSError: pass
        except Exception:
            pass
        finally:
            if server is not None:
                try: server.close()
                except Exception: pass


# ── Main App ──────────────────────────────────────────────────────────────────

class RSCTransferApp(tk.Tk):

    BG  = "#1a1a2e"
    FG  = "#e0e0e0"
    ACC = "#00b4d8"
    BTN = "#0077b6"
    DRK = "#16213e"
    OK  = "#06d6a0"
    ERR = "#ef233c"
    WRN = "#ffd166"

    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} v{APP_VER} — GTA Online Character Transfer")
        self.geometry("960x720")
        self.minsize(820, 600)
        self.configure(bg=self.BG)

        self._proxy_thread: Optional[threading.Thread] = None
        self._proxy: Optional[MITMProxy] = None
        self._running = False
        self._cert_cache: Optional[CertCache] = None
        self._captures: List[Capture] = []
        self._inject_map: Dict[str, Capture] = {}
        self._log_q:     queue.Queue = queue.Queue(maxsize=5000)
        self._capture_q: queue.Queue = queue.Queue(maxsize=5000)

        for d in (DATA_DIR, CERT_DIR, CAPTURE_DIR):
            d.mkdir(parents=True, exist_ok=True)

        self._build_ui()
        self._poll_queues()

        if CA_CERT.exists() and CA_KEY.exists():
            self._load_ca()

        # initialise the LAN IP display (Xbox section)
        self.after(100, self._refresh_lan_ip)

    def _build_ui(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TNotebook",         background=self.BG, borderwidth=0)
        style.configure("TNotebook.Tab",     background=self.DRK, foreground=self.FG,
                        padding=[14, 7], font=("Segoe UI", 10, "bold"))
        style.map("TNotebook.Tab",
                  background=[("selected", self.ACC)],
                  foreground=[("selected", "#000")])
        style.configure("TFrame",      background=self.BG)
        style.configure("TLabel",      background=self.BG, foreground=self.FG,
                        font=("Segoe UI", 10))
        style.configure("TButton",     background=self.BTN, foreground=self.FG,
                        font=("Segoe UI", 10, "bold"), borderwidth=0, padding=6)
        style.map("TButton",
                  background=[("active", self.ACC), ("disabled", "#444")],
                  foreground=[("active", "#000")])
        style.configure("TLabelframe",       background=self.BG, foreground=self.ACC,
                        font=("Segoe UI", 10, "bold"))
        style.configure("TLabelframe.Label", background=self.BG, foreground=self.ACC,
                        font=("Segoe UI", 10, "bold"))
        style.configure("TEntry",      fieldbackground=self.DRK, foreground=self.FG,
                        insertcolor=self.FG)

        hdr = tk.Frame(self, bg=self.BTN, pady=8)
        hdr.pack(fill=tk.X)
        tk.Label(hdr, text=f"  ▶  {APP_NAME} — GTA Online Character Transfer",
                 bg=self.BTN, fg="white",
                 font=("Segoe UI", 13, "bold")).pack(side=tk.LEFT)
        tk.Label(hdr, text=f"v{APP_VER}  ",
                 bg=self.BTN, fg="#cce7ff",
                 font=("Segoe UI", 10)).pack(side=tk.RIGHT)

        self._nb = ttk.Notebook(self)
        self._nb.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

        self._tab_setup   = ttk.Frame(self._nb)
        self._tab_capture = ttk.Frame(self._nb)
        self._tab_inject  = ttk.Frame(self._nb)
        self._tab_log     = ttk.Frame(self._nb)

        self._nb.add(self._tab_setup,   text="  ① Setup  ")
        self._nb.add(self._tab_capture, text="  ② Capture  ")
        self._nb.add(self._tab_inject,  text="  ③ Inject  ")
        self._nb.add(self._tab_log,     text="  ④ Log  ")

        self._build_setup_tab()
        self._build_capture_tab()
        self._build_inject_tab()
        self._build_log_tab()

        self._status_var = tk.StringVar(value="Ready. Start with the Setup tab.")
        sb = tk.Label(self, textvariable=self._status_var,
                      bg="#0d0d1a", fg=self.ACC,
                      font=("Consolas", 9), anchor=tk.W, pady=4, padx=8)
        sb.pack(fill=tk.X, side=tk.BOTTOM)

    def _build_setup_tab(self):
        f = self._tab_setup
        pad = {"padx": 14, "pady": 8}

        lf1 = ttk.LabelFrame(f, text=" Step 1 — Generate & Install CA Certificate ")
        lf1.pack(fill=tk.X, **pad)

        tk.Label(lf1, text=(
            "RSCTransfer needs a root certificate so GTA's HTTPS traffic\n"
            "can be intercepted on your PC. It is installed into your\n"
            "user-only Windows certificate store (no admin needed).\n"
            "You can remove it any time using the Remove CA button."
        ), justify=tk.LEFT, bg=self.BG, fg=self.FG,
            font=("Segoe UI", 10)).pack(anchor=tk.W, padx=10, pady=4)

        self._cert_status = tk.StringVar(value="◌  No certificate found")
        self._cert_status_lbl = tk.Label(
            lf1, textvariable=self._cert_status,
            font=("Segoe UI", 10, "bold"),
            bg=self.BG, fg=self.WRN
        )
        self._cert_status_lbl.pack(anchor=tk.W, padx=10)

        bf = tk.Frame(lf1, bg=self.BG)
        bf.pack(fill=tk.X, padx=10, pady=8)
        ttk.Button(bf, text="Generate + Install CA",
                   command=self._do_generate_ca).pack(side=tk.LEFT, padx=4)
        ttk.Button(bf, text="Remove CA",
                   command=self._do_remove_ca).pack(side=tk.LEFT, padx=4)
        ttk.Button(bf, text="Open Cert Folder",
                   command=lambda: self._open_folder(CERT_DIR)).pack(side=tk.LEFT, padx=4)

        lf2 = ttk.LabelFrame(f, text=" Step 2 — Configure Proxy Port ")
        lf2.pack(fill=tk.X, **pad)

        pf = tk.Frame(lf2, bg=self.BG)
        pf.pack(fill=tk.X, padx=10, pady=8)
        tk.Label(pf, text="Proxy port:", bg=self.BG, fg=self.FG,
                 font=("Segoe UI", 10)).pack(side=tk.LEFT)
        self._port_var = tk.StringVar(value=str(DEFAULT_PORT))
        tk.Entry(pf, textvariable=self._port_var, width=8,
                 font=("Consolas", 11),
                 bg=self.DRK, fg=self.FG, insertbackground=self.FG,
                 relief=tk.FLAT).pack(side=tk.LEFT, padx=8)
        tk.Label(pf, text="(default 8080)", bg=self.BG, fg="#888",
                 font=("Segoe UI", 9)).pack(side=tk.LEFT)

        lf3 = ttk.LabelFrame(f, text=" Step 3 — Connect Your Device to the Proxy ")
        lf3.pack(fill=tk.X, **pad)

        # ── Mode toggle ───────────────────────────────────────────────────────
        mode_row = tk.Frame(lf3, bg=self.BG)
        mode_row.pack(fill=tk.X, padx=10, pady=(8, 2))
        tk.Label(mode_row, text="Source device:", bg=self.BG, fg=self.FG,
                 font=("Segoe UI", 10)).pack(side=tk.LEFT)
        self._xbox_mode = tk.BooleanVar(value=False)
        tk.Radiobutton(mode_row, text=" PC (Social Club login on this machine) ",
                       variable=self._xbox_mode, value=False,
                       command=self._refresh_step3,
                       bg=self.BG, fg=self.FG, selectcolor=self.DRK,
                       activebackground=self.BG, activeforeground=self.FG,
                       font=("Segoe UI", 10)).pack(side=tk.LEFT, padx=10)
        tk.Radiobutton(mode_row, text=" Xbox Console ",
                       variable=self._xbox_mode, value=True,
                       command=self._refresh_step3,
                       bg=self.BG, fg=self.WRN, selectcolor=self.DRK,
                       activebackground=self.BG, activeforeground=self.WRN,
                       font=("Segoe UI", 10, "bold")).pack(side=tk.LEFT)

        # ── PC instructions (shown by default) ────────────────────────────────
        self._step3_pc = tk.Frame(lf3, bg=self.BG)
        tk.Label(self._step3_pc, text=(
            "After starting the proxy (Capture tab), set your system proxy to:\n\n"
            "    Address: 127.0.0.1     Port: (your port above)\n\n"
            "Windows Settings → Network & Internet → Proxy → Manual proxy setup → ON\n\n"
            "GTA Online will route through the proxy automatically.\n"
            "Turn the system proxy off when you're done."
        ), justify=tk.LEFT, bg=self.BG, fg=self.FG,
            font=("Segoe UI", 10)).pack(anchor=tk.W, padx=10, pady=4)
        ttk.Button(self._step3_pc, text="Open Windows Proxy Settings",
                   command=self._open_proxy_settings).pack(padx=10, pady=6, anchor=tk.W)
        self._step3_pc.pack(fill=tk.X)

        # ── Xbox instructions (hidden until Xbox mode selected) ────────────────
        self._step3_xbox = tk.Frame(lf3, bg=self.BG)

        # LAN IP display
        ip_row = tk.Frame(self._step3_xbox, bg=self.DRK, padx=10, pady=6)
        ip_row.pack(fill=tk.X, padx=10, pady=(8, 2))
        tk.Label(ip_row, text="Your PC's LAN IP  →  ", bg=self.DRK,
                 fg="#888", font=("Segoe UI", 10)).pack(side=tk.LEFT)
        self._lan_ip_var = tk.StringVar(value="(detecting…)")
        tk.Label(ip_row, textvariable=self._lan_ip_var, bg=self.DRK,
                 fg=self.ACC, font=("Consolas", 13, "bold")).pack(side=tk.LEFT)
        ttk.Button(ip_row, text="↺ Refresh",
                   command=self._refresh_lan_ip).pack(side=tk.LEFT, padx=10)

        xbox_cert_frame = ttk.LabelFrame(self._step3_xbox, text=" A — Install CA cert on Xbox ")
        xbox_cert_frame.pack(fill=tk.X, padx=10, pady=6)
        self._cert_url_var = tk.StringVar(value="Start the proxy first, then the URL will appear here.")
        tk.Label(xbox_cert_frame, textvariable=self._cert_url_var,
                 bg=self.BG, fg=self.ACC, font=("Consolas", 11)).pack(anchor=tk.W, padx=10, pady=4)
        tk.Label(xbox_cert_frame, text=(
            "1. Start the proxy (Capture tab).\n"
            "2. On Xbox: Settings → General → Network Settings → Advanced Settings\n"
            "      → Proxy Settings → Manual → enter the IP and port above.\n"
            "3. Open Edge on Xbox (My Games & Apps → Apps → Microsoft Edge).\n"
            "4. Navigate to the URL shown above  — accept/Install the certificate.\n"
            "5. You can remove the proxy from Xbox settings when done."
        ), justify=tk.LEFT, bg=self.BG, fg=self.FG,
            font=("Segoe UI", 10)).pack(anchor=tk.W, padx=10, pady=(0, 6))

        cert_btn_row = tk.Frame(xbox_cert_frame, bg=self.BG)
        cert_btn_row.pack(fill=tk.X, padx=10, pady=(0, 8))
        ttk.Button(cert_btn_row, text="Export CA cert to USB…",
                   command=self._do_export_ca_usb).pack(side=tk.LEFT, padx=4)
        tk.Label(cert_btn_row,
                 text="  (copy to USB as alternative if Edge cert install doesn't prompt)",
                 bg=self.BG, fg="#888", font=("Segoe UI", 9)).pack(side=tk.LEFT)

        xbox_proxy_frame = ttk.LabelFrame(self._step3_xbox, text=" B — Xbox Proxy Settings path ")
        xbox_proxy_frame.pack(fill=tk.X, padx=10, pady=6)
        tk.Label(xbox_proxy_frame, text=(
            "Settings → General → Network Settings → Advanced Settings\n"
            "  → IP Settings → Manual\n"
            "  → Proxy Settings → On → enter PC LAN IP + port"
        ), justify=tk.LEFT, bg=self.BG, fg=self.FG,
            font=("Segoe UI", 10)).pack(anchor=tk.W, padx=10, pady=6)

        lf4 = ttk.LabelFrame(f, text=" Step 4 — Account Switching Guide ")
        lf4.pack(fill=tk.X, **pad)

        tk.Label(lf4, text=(
            "CAPTURE PHASE:\n"
            "  • Sign into Rockstar Social Club with your XBOX account\n"
            "  • Launch GTA Online — let it fully load into a session\n"
            "  • The proxy captures character init payloads (★ marked)\n\n"
            "INJECT PHASE:\n"
            "  • Sign out, sign back in with your PC Social Club account\n"
            "  • Switch to Inject tab, select the captured ★ payloads\n"
            "  • Enable inject, launch GTA Online\n"
            "  • Run FSL alongside this to keep saves local"
        ), justify=tk.LEFT, bg=self.BG, fg=self.FG,
            font=("Segoe UI", 10)).pack(anchor=tk.W, padx=10, pady=4)

    def _refresh_step3(self):
        """Toggle between PC and Xbox proxy instructions."""
        if self._xbox_mode.get():
            self._step3_pc.pack_forget()
            self._step3_xbox.pack(fill=tk.X)
            self._refresh_lan_ip()
        else:
            self._step3_xbox.pack_forget()
            self._step3_pc.pack(fill=tk.X)

    def _refresh_lan_ip(self):
        """Detect and display LAN IP addresses; update the cert URL label."""
        ips = get_local_ips()
        primary = ips[0][1] if ips else "0.0.0.0"
        if len(ips) == 1:
            self._lan_ip_var.set(primary)
        else:
            all_ips = "  /  ".join(f"{lbl}: {ip}" for lbl, ip in ips)
            self._lan_ip_var.set(all_ips)
        port = self._port_var.get().strip() or str(DEFAULT_PORT)
        if self._running:
            self._cert_url_var.set(f"http://{primary}:{port}/ca.crt")
        else:
            self._cert_url_var.set(f"(start proxy first)  http://{primary}:{port}/ca.crt")

    def _do_export_ca_usb(self):
        """Save the CA cert file to a location the user chooses (USB drive etc.)."""
        if not CA_CERT.exists():
            messagebox.showerror("No certificate",
                "Generate the CA certificate first (Step 1).")
            return
        dest = filedialog.asksaveasfilename(
            defaultextension=".crt",
            filetypes=[("Certificate", "*.crt"), ("PEM", "*.pem"), ("All files", "*.*")],
            initialfile="RSCTransfer_CA.crt",
            title="Export CA cert — save to USB drive or any folder",
        )
        if not dest:
            return
        try:
            import shutil
            shutil.copy2(str(CA_CERT), dest)
            self._status_var.set(f"CA cert exported to {dest}")
            messagebox.showinfo("Exported",
                f"CA cert saved to:\n{dest}\n\n"
                "On Xbox, navigate to it in Edge or\n"
                "use the http://[PC-IP]:[port]/ca.crt URL instead.")
        except Exception as e:
            messagebox.showerror("Export failed", str(e))

    def _build_capture_tab(self):
        f = self._tab_capture

        ctrl = tk.Frame(f, bg=self.BG)
        ctrl.pack(fill=tk.X, padx=14, pady=10)

        self._proxy_btn = ttk.Button(ctrl, text="▶  Start Proxy",
                                     command=self._toggle_proxy)
        self._proxy_btn.pack(side=tk.LEFT, padx=4)

        ttk.Button(ctrl, text="Clear list",
                   command=self._clear_captures).pack(side=tk.LEFT, padx=4)
        ttk.Button(ctrl, text="Save all to file…",
                   command=self._save_captures).pack(side=tk.LEFT, padx=4)
        ttk.Button(ctrl, text="Load from file…",
                   command=self._load_captures).pack(side=tk.LEFT, padx=4)

        self._proxy_status_var = tk.StringVar(value="● Stopped")
        self._proxy_status_lbl = tk.Label(
            ctrl, textvariable=self._proxy_status_var,
            font=("Consolas", 11, "bold"),
            bg=self.BG, fg=self.ERR
        )
        self._proxy_status_lbl.pack(side=tk.RIGHT, padx=8)

        ff = tk.Frame(f, bg=self.BG)
        ff.pack(fill=tk.X, padx=14)
        self._char_only = tk.BooleanVar(value=False)
        tk.Checkbutton(ff, text="Show character payloads only  (★)",
                       variable=self._char_only,
                       command=self._refresh_capture_list,
                       bg=self.BG, fg=self.FG,
                       selectcolor=self.DRK,
                       activebackground=self.BG, activeforeground=self.FG,
                       font=("Segoe UI", 10)).pack(side=tk.LEFT)

        body = tk.Frame(f, bg=self.BG)
        body.pack(fill=tk.BOTH, expand=True, padx=14, pady=8)

        lf = ttk.LabelFrame(body, text=" Captured Payloads  (★ = likely character data) ")
        lf.pack(fill=tk.BOTH, expand=True)

        inner = tk.Frame(lf, bg="#0d1b2a")
        inner.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

        self._cap_listbox = tk.Listbox(
            inner, bg="#0d1b2a", fg=self.FG,
            selectbackground=self.ACC, selectforeground="#000",
            font=("Consolas", 9), activestyle="none",
            borderwidth=0, highlightthickness=0,
            selectmode=tk.EXTENDED,
        )
        self._cap_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self._cap_listbox.bind("<<ListboxSelect>>", self._on_cap_select)

        sb = ttk.Scrollbar(inner, orient=tk.VERTICAL,
                           command=self._cap_listbox.yview)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self._cap_listbox.config(yscrollcommand=sb.set)

        pf = ttk.LabelFrame(f, text=" Payload Preview ")
        pf.pack(fill=tk.X, padx=14, pady=8)
        self._preview = scrolledtext.ScrolledText(
            pf, height=10, bg="#0d1b2a", fg=self.FG,
            font=("Consolas", 9), state=tk.DISABLED,
            borderwidth=0, highlightthickness=0,
        )
        self._preview.pack(fill=tk.X, padx=2, pady=2)

        ttk.Button(f, text="Send selected to Inject  →",
                   command=self._send_to_inject).pack(pady=10)

    def _build_inject_tab(self):
        f = self._tab_inject

        tk.Label(f, text=(
            "Selected payloads here will be served in place of the real Rockstar\n"
            "response when GTA Online initializes your character. Keep the proxy\n"
            "running with inject mode ON before launching GTA."
        ), justify=tk.LEFT, bg=self.BG, fg=self.FG,
            font=("Segoe UI", 10)).pack(padx=14, pady=10, anchor=tk.W)

        ctrl = tk.Frame(f, bg=self.BG)
        ctrl.pack(fill=tk.X, padx=14, pady=4)

        self._inject_active = tk.BooleanVar(value=False)
        tk.Checkbutton(ctrl, text="  Inject mode ON",
                       variable=self._inject_active,
                       command=self._update_inject_mode,
                       bg=self.BG, fg=self.OK,
                       selectcolor=self.DRK,
                       activebackground=self.BG, activeforeground=self.OK,
                       font=("Segoe UI", 11, "bold")).pack(side=tk.LEFT)

        ttk.Button(ctrl, text="Remove selected",
                   command=self._remove_selected_inject).pack(side=tk.LEFT, padx=10)
        ttk.Button(ctrl, text="Clear queue",
                   command=self._clear_inject).pack(side=tk.LEFT, padx=4)

        lf = ttk.LabelFrame(f, text=" Inject Queue (host+path → payload) ")
        lf.pack(fill=tk.BOTH, expand=True, padx=14, pady=8)

        inner2 = tk.Frame(lf, bg="#0d1b2a")
        inner2.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

        self._inject_listbox = tk.Listbox(
            inner2, bg="#0d1b2a", fg=self.OK,
            selectbackground=self.ACC, selectforeground="#000",
            font=("Consolas", 9), activestyle="none",
            borderwidth=0, highlightthickness=0,
            selectmode=tk.EXTENDED,
        )
        self._inject_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        sb2 = ttk.Scrollbar(inner2, orient=tk.VERTICAL,
                            command=self._inject_listbox.yview)
        sb2.pack(side=tk.RIGHT, fill=tk.Y)
        self._inject_listbox.config(yscrollcommand=sb2.set)

        tk.Label(f, text=(
            "TIP: Run FSL (WINMM.dll) at the same time so Rockstar doesn't\n"
            "     overwrite your character with PC account server-side data."
        ), bg=self.BG, fg=self.WRN, justify=tk.LEFT,
            font=("Segoe UI", 10)).pack(padx=14, pady=8, anchor=tk.W)

    def _build_log_tab(self):
        f = self._tab_log

        ctrl = tk.Frame(f, bg=self.BG)
        ctrl.pack(fill=tk.X, padx=14, pady=8)
        ttk.Button(ctrl, text="Clear log",
                   command=self._clear_log).pack(side=tk.LEFT)
        ttk.Button(ctrl, text="Copy to clipboard",
                   command=self._copy_log).pack(side=tk.LEFT, padx=6)

        self._log_box = scrolledtext.ScrolledText(
            f, bg="#0d1b2a", fg="#90e0ef",
            font=("Consolas", 9), state=tk.DISABLED,
            borderwidth=0, highlightthickness=0,
        )
        self._log_box.pack(fill=tk.BOTH, expand=True, padx=14, pady=8)

    def _do_generate_ca(self):
        if not CRYPTO_OK:
            messagebox.showerror("Error",
                "cryptography package not installed.\nRun:\n\n  pip install cryptography")
            return
        try:
            cert_pem, key_pem = generate_ca()
            CA_CERT.write_bytes(cert_pem)
            CA_KEY.write_bytes(key_pem)
            ok, out = install_ca_windows(CA_CERT)
            if ok:
                self._cert_status.set("✔  CA installed in Windows Trusted Root (user)")
                self._cert_status_lbl.config(fg=self.OK)
                messagebox.showinfo("Done",
                    "CA certificate installed successfully.\n\n"
                    "You can now go to the Capture tab and start the proxy.")
            else:
                self._cert_status.set("⚠  CA generated but install failed — see log")
                self._cert_status_lbl.config(fg=self.WRN)
                self._log(f"certutil output: {out}")
                messagebox.showwarning(
                    "Manual install needed",
                    f"Automatic install failed.\n\n"
                    f"Run this in a terminal:\n\n"
                    f"  certutil -user -addstore Root \"{CA_CERT}\"\n\n"
                    f"Output:\n{out[:400]}"
                )
            self._load_ca()
        except Exception as e:
            messagebox.showerror("Error", f"{type(e).__name__}: {e}")
            self._log(f"generate_ca error: {e}")

    def _do_remove_ca(self):
        if messagebox.askyesno("Remove CA?",
            "This will remove the RSCTransfer root certificate from\n"
            "Windows and delete the local key files.\n\nContinue?") is not True:
            return
        ok, out = remove_ca_windows()
        for p in (CA_CERT, CA_KEY):
            if p.exists():
                try: p.unlink()
                except Exception: pass
        self._cert_status.set("◌  Certificate removed" if ok else "⚠  Removal had issues — see log")
        self._cert_status_lbl.config(fg="#888" if ok else self.WRN)
        self._cert_cache = None
        if not ok:
            self._log(f"remove_ca output: {out}")

    def _load_ca(self):
        if not (CA_CERT.exists() and CA_KEY.exists() and CRYPTO_OK):
            return
        try:
            ca_cert_pem = CA_CERT.read_bytes()
            ca_key_pem  = CA_KEY.read_bytes()
            self._cert_cache = CertCache(ca_cert_pem, ca_key_pem)
            self._cert_status.set("✔  CA loaded and ready")
            self._cert_status_lbl.config(fg=self.OK)
        except Exception as e:
            self._log(f"load_ca error: {e}")
            self._cert_status.set("⚠  Failed to load CA — regenerate")
            self._cert_status_lbl.config(fg=self.ERR)

    def _toggle_proxy(self):
        if self._running:
            self._stop_proxy()
        else:
            self._start_proxy()

    def _start_proxy(self):
        if not self._cert_cache:
            messagebox.showerror("Error", "Generate & install the CA certificate first (Setup tab).")
            return
        try:
            port = int(self._port_var.get().strip())
            if not (1 <= port <= 65535):
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "Invalid port number. Use 1-65535.")
            return

        self._proxy = MITMProxy(
            port        = port,
            cert_cache  = self._cert_cache,
            log_q       = self._log_q,
            capture_q   = self._capture_q,
            inject_mode = self._inject_active.get(),
            inject_map  = self._inject_map,
        )
        self._running = True
        self._proxy_thread = threading.Thread(target=self._proxy.start, daemon=True)
        self._proxy_thread.start()

        time.sleep(0.25)
        if self._proxy._server_sock is None:
            self._running = False
            self._proxy = None
            messagebox.showerror("Error",
                f"Could not bind to port {port}. Check the log tab.\n"
                f"Try a different port, or run as Administrator.")
            return

        self._proxy_btn.config(text="■  Stop Proxy")
        self._proxy_status_var.set(f"● Running on :{port}")
        self._proxy_status_lbl.config(fg=self.OK)
        lan_ips = get_local_ips()
        primary = lan_ips[0][1] if lan_ips else "127.0.0.1"
        self._status_var.set(
            f"Proxy running  —  PC: 127.0.0.1:{port}  |  Xbox/LAN: {primary}:{port}"
        )
        # Update cert URL in Xbox section now that we know we're running
        if hasattr(self, "_cert_url_var"):
            self._cert_url_var.set(f"http://{primary}:{port}/ca.crt")

    def _stop_proxy(self):
        if self._proxy:
            self._proxy.stop()
        self._running = False
        self._proxy = None
        self._proxy_btn.config(text="▶  Start Proxy")
        self._proxy_status_var.set("● Stopped")
        self._proxy_status_lbl.config(fg=self.ERR)
        self._status_var.set("Proxy stopped.")

    def _update_inject_mode(self):
        mode = self._inject_active.get()
        if self._proxy:
            self._proxy.set_inject(mode, self._inject_map)
        self._status_var.set(f"Inject mode {'ON' if mode else 'OFF'}")

    def _visible_captures(self) -> List[Capture]:
        return [c for c in self._captures
                if (not self._char_only.get()) or c.is_char]

    def _refresh_capture_list(self):
        self._cap_listbox.delete(0, tk.END)
        for cap in self._visible_captures():
            self._cap_listbox.insert(tk.END, cap.label)
            if cap.is_char:
                self._cap_listbox.itemconfig(tk.END, fg=self.OK)

    def _on_cap_select(self, _event=None):
        sel = self._cap_listbox.curselection()
        if not sel:
            return
        visible = self._visible_captures()
        idx = sel[0]
        if idx >= len(visible):
            return
        cap = visible[idx]
        self._preview.config(state=tk.NORMAL)
        self._preview.delete("1.0", tk.END)
        try:
            pretty = json.dumps(json.loads(cap.body.decode("utf-8", errors="replace")), indent=2)
        except Exception:
            pretty = cap.body.decode("utf-8", errors="replace")
        if len(pretty) > 20000:
            pretty = pretty[:20000] + f"\n\n… (truncated, full size {len(cap.body)}b)"
        self._preview.insert(tk.END,
            f"Host:    {cap.host}\n"
            f"Path:    {cap.path}\n"
            f"Method:  {cap.method}\n"
            f"Status:  {cap.status}\n"
            f"Type:    {cap.content_type}\n"
            f"Size:    {len(cap.body)} bytes\n"
            f"Time:    {cap.ts_str}\n"
            f"Char?:   {'YES  ★' if cap.is_char else 'No'}\n"
            f"{'─'*70}\n{pretty}"
        )
        self._preview.config(state=tk.DISABLED)

    def _send_to_inject(self):
        sel = self._cap_listbox.curselection()
        if not sel:
            messagebox.showinfo("Select a capture", "Click a captured payload in the list first.")
            return
        visible = self._visible_captures()
        added = 0
        for idx in sel:
            if idx >= len(visible):
                continue
            cap = visible[idx]
            key = f"{cap.host}{cap.path}"
            self._inject_map[key] = cap
            self._inject_listbox.insert(tk.END, f"{key}  ({len(cap.body)}b)")
            added += 1
        if self._proxy:
            self._proxy.set_inject(self._inject_active.get(), self._inject_map)
        self._status_var.set(f"Added {added} payload(s) to inject queue.")

    def _remove_selected_inject(self):
        sel = self._inject_listbox.curselection()
        if not sel:
            return
        items = list(self._inject_map.items())
        new_items = [it for i, it in enumerate(items) if i not in sel]
        self._inject_map = dict(new_items)
        self._inject_listbox.delete(0, tk.END)
        for key, cap in self._inject_map.items():
            self._inject_listbox.insert(tk.END, f"{key}  ({len(cap.body)}b)")
        if self._proxy:
            self._proxy.set_inject(self._inject_active.get(), self._inject_map)

    def _clear_inject(self):
        self._inject_map.clear()
        self._inject_listbox.delete(0, tk.END)
        if self._proxy:
            self._proxy.set_inject(self._inject_active.get(), self._inject_map)

    def _clear_captures(self):
        self._captures.clear()
        self._refresh_capture_list()
        self._preview.config(state=tk.NORMAL)
        self._preview.delete("1.0", tk.END)
        self._preview.config(state=tk.DISABLED)

    def _save_captures(self):
        if not self._captures:
            messagebox.showinfo("No captures", "Nothing to save yet.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON", "*.json")],
            initialdir=str(CAPTURE_DIR),
            initialfile=f"captures_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
            title="Save captures",
        )
        if not path:
            return
        try:
            data = [c.to_dict() for c in self._captures]
            Path(path).write_text(json.dumps(data, indent=2))
            self._status_var.set(f"Saved {len(self._captures)} captures to {path}")
        except Exception as e:
            messagebox.showerror("Save failed", str(e))

    def _load_captures(self):
        path = filedialog.askopenfilename(
            filetypes=[("JSON", "*.json")],
            initialdir=str(CAPTURE_DIR),
            title="Load captures",
        )
        if not path:
            return
        try:
            data = json.loads(Path(path).read_text())
            loaded = [Capture.from_dict(d) for d in data]
            self._captures.extend(loaded)
            self._refresh_capture_list()
            self._status_var.set(f"Loaded {len(loaded)} captures from {path}")
        except Exception as e:
            messagebox.showerror("Load error", str(e))

    def _clear_log(self):
        self._log_box.config(state=tk.NORMAL)
        self._log_box.delete("1.0", tk.END)
        self._log_box.config(state=tk.DISABLED)

    def _copy_log(self):
        try:
            text = self._log_box.get("1.0", tk.END)
            self.clipboard_clear()
            self.clipboard_append(text)
            self._status_var.set("Log copied to clipboard.")
        except Exception as e:
            self._status_var.set(f"Copy failed: {e}")

    def _log(self, msg: str):
        try:
            self._log_q.put_nowait(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] {msg}")
        except queue.Full:
            pass

    def _open_proxy_settings(self):
        if os.name == "nt":
            try:
                subprocess.Popen(["cmd", "/c", "start", "ms-settings:network-proxy"], shell=False)
            except Exception:
                try:
                    os.startfile("ms-settings:network-proxy")  # type: ignore
                except Exception as e:
                    self._log(f"Open proxy settings: {e}")
        else:
            messagebox.showinfo("Not Windows", "Open your system proxy settings manually.")

    def _open_folder(self, path: Path):
        if os.name == "nt":
            try:
                os.startfile(str(path))  # type: ignore
            except Exception as e:
                self._log(f"open folder: {e}")
        else:
            try:
                subprocess.Popen(["xdg-open", str(path)])
            except Exception:
                pass

    def _poll_queues(self):
        for _ in range(200):
            if self._log_q.empty():
                break
            try:
                msg = self._log_q.get_nowait()
            except queue.Empty:
                break
            self._log_box.config(state=tk.NORMAL)
            self._log_box.insert(tk.END, msg + "\n")
            self._log_box.see(tk.END)
            self._log_box.config(state=tk.DISABLED)

        new_char = False
        for _ in range(200):
            if self._capture_q.empty():
                break
            try:
                cap: Capture = self._capture_q.get_nowait()
            except queue.Empty:
                break
            self._captures.append(cap)
            if (not self._char_only.get()) or cap.is_char:
                self._cap_listbox.insert(tk.END, cap.label)
                if cap.is_char:
                    self._cap_listbox.itemconfig(tk.END, fg=self.OK)
                    new_char = True

        if new_char:
            self._status_var.set("★  New character payload captured!")

        self.after(150, self._poll_queues)

    def on_close(self):
        if self._running:
            self._stop_proxy()
        self.destroy()


def main():
    if not CRYPTO_OK:
        try:
            import tkinter.messagebox as mb
            root = tk.Tk()
            root.withdraw()
            mb.showerror(
                "Missing dependency",
                "The 'cryptography' package is required.\n\n"
                "Open a terminal and run:\n"
                "    pip install cryptography\n\n"
                "Then restart RSCTransfer."
            )
            root.destroy()
        except Exception:
            print("ERROR: cryptography package not installed. Run: pip install cryptography")
        return

    app = RSCTransferApp()
    app.protocol("WM_DELETE_WINDOW", app.on_close)
    app.mainloop()


if __name__ == "__main__":
    main()
