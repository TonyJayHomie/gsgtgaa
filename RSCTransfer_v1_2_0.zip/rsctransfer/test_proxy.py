"""Comprehensive functional test of RSCTransfer.

Run:  python test_proxy.py
Expected: 18 passed, 0 failed
"""
import sys, unittest.mock
sys.modules['tkinter'] = unittest.mock.MagicMock()
sys.modules['tkinter.ttk'] = unittest.mock.MagicMock()
sys.modules['tkinter.messagebox'] = unittest.mock.MagicMock()
sys.modules['tkinter.scrolledtext'] = unittest.mock.MagicMock()
sys.modules['tkinter.filedialog'] = unittest.mock.MagicMock()

import importlib.util
spec = importlib.util.spec_from_file_location('rsc', 'RSCTransfer.py')
rsc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rsc)

import warnings; warnings.filterwarnings("ignore")

passed = failed = 0
def ok(t):
    global passed; passed += 1; print(f"  PASS  {t}")
def fail(t, e=""):
    global failed; failed += 1; print(f"  FAIL  {t}  {e}")

print(f"\n========== Testing {rsc.APP_NAME} v{rsc.APP_VER} ==========\n")

print("Test 1: timezone-aware datetime...")
warnings.filterwarnings("error", category=DeprecationWarning)
try:
    t = rsc._utcnow()
    assert t.tzinfo is not None
    ok("uses timezone-aware datetime")
except DeprecationWarning as e:
    fail("utcnow deprecation", e)
warnings.filterwarnings("ignore")

print("Test 2: CA cert generation...")
cert_pem, key_pem = rsc.generate_ca()
assert b"BEGIN CERTIFICATE" in cert_pem and b"BEGIN RSA PRIVATE KEY" in key_pem
ok("CA cert PEM format")

print("Test 3: Host cert generation...")
host_cert, host_key = rsc.generate_host_cert("test.rockstargames.com", cert_pem, key_pem)
assert b"BEGIN CERTIFICATE" in host_cert
ok("Host cert PEM format")

from cryptography import x509
from cryptography.hazmat.backends import default_backend
hc = x509.load_pem_x509_certificate(host_cert, default_backend())
try:
    hc.extensions.get_extension_for_class(x509.AuthorityKeyIdentifier)
    ok("Host cert has Authority Key Identifier")
except x509.ExtensionNotFound:
    fail("missing AKI extension")

print("Test 4: HTTP response parsing...")
sample = b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 20\r\n\r\n{\"x\":\"test\",\"y\":123}"
status, headers, body = rsc.parse_http_response(sample)
assert status == 200 and body == b'{"x":"test","y":123}'
ok("standard HTTP/1.1 200")

chunked_body = b"5\r\nhello\r\n5\r\nworld\r\n0\r\n\r\n"
sample = b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n" + chunked_body
status, headers, body = rsc.parse_http_response(sample)
assert body == b"helloworld"
ok("chunked transfer encoding")

sample = b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n5;name=ext\r\nhello\r\n0\r\n\r\n"
status, headers, body = rsc.parse_http_response(sample)
assert body == b"hello"
ok("chunked with extensions")

print("Test 7: Content encoding...")
import gzip, zlib
gz = gzip.compress(b'{"characterData":"x"}')
sample = b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Encoding: gzip\r\nContent-Length: " + str(len(gz)).encode() + b"\r\n\r\n" + gz
status, headers, body = rsc.parse_http_response(sample)
assert b"characterData" in body
ok("gzip decoding")

dz = zlib.compress(b'{"characterData":"y"}')
sample = b"HTTP/1.1 200 OK\r\nContent-Encoding: deflate\r\n\r\n" + dz
status, headers, body = rsc.parse_http_response(sample)
assert b"characterData" in body
ok("deflate decoding")

print("Test 8: Capture detection...")
cap = rsc.Capture("scapi.rockstargames.com", "/p/123", "GET", 200,
                  b'{"characterData":1}', "application/json", 0)
assert cap.is_char
ok("character signal detected")

cap2 = rsc.Capture("rockstargames.com", "/static", "GET", 200,
                   b'{"v":"1.0"}', "application/json", 0)
assert not cap2.is_char
ok("non-character payload not flagged")

cap3 = rsc.Capture("rockstargames.com", "/x", "GET", 200,
                   b'{"wallet": 5000}', "application/json", 0)
assert cap3.is_char
ok("wallet signal detected")

print("Test 9: Serialization (binary-safe)...")
binary = bytes(range(256))
cap = rsc.Capture("rockstargames.com", "/binary", "POST", 200, binary, "application/octet-stream", 0)
d = cap.to_dict()
import json as _json
_json.dumps(d)
restored = rsc.Capture.from_dict(d)
assert restored.body == binary
ok("binary-safe serialization roundtrip")

print("Test 10: Domain matching...")
import queue
log_q, cap_q = queue.Queue(), queue.Queue()
proxy = rsc.MITMProxy(0, rsc.CertCache(cert_pem, key_pem), log_q, cap_q)
assert proxy._is_rsc("rockstargames.com")
assert proxy._is_rsc("scapi.rockstargames.com")
assert proxy._is_rsc("prod.cloud.rockstargames.com")
assert proxy._is_rsc("any.subdomain.rockstargames.com")
assert not proxy._is_rsc("google.com")
ok("rockstar domains matched correctly")

assert not proxy._is_rsc("rockstargames.com.evil.tld")
assert not proxy._is_rsc("evil-rockstargames.com")
ok("domain spoofing attempts rejected")

print("Test 11: LIVE MITM proxy + intercept test...")
import threading, time, ssl, socket, http.server, tempfile, os

CHAR_RESP = b'{"characterData":{"name":"TestXboxPlayer","money":2147483647,"rank":250}}'

class FakeRSC(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        body = CHAR_RESP
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)
    def log_message(self, *a, **k): pass

fake_cert, fake_key = rsc.generate_host_cert("rockstargames.com", cert_pem, key_pem)
with tempfile.NamedTemporaryFile(delete=False, suffix='.pem') as f: f.write(fake_cert); fcrt = f.name
with tempfile.NamedTemporaryFile(delete=False, suffix='.pem') as f: f.write(fake_key); fkey = f.name
with tempfile.NamedTemporaryFile(delete=False, suffix='.pem') as f: f.write(cert_pem); fca = f.name

srv = http.server.HTTPServer(("127.0.0.1", 0), FakeRSC)
ctx_srv = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ctx_srv.load_cert_chain(fcrt, fkey)
srv.socket = ctx_srv.wrap_socket(srv.socket, server_side=True)
fake_port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

proxy_port = 19443
log_q = queue.Queue()
cap_q = queue.Queue()
proxy2 = rsc.MITMProxy(
    port=proxy_port,
    cert_cache=rsc.CertCache(cert_pem, key_pem),
    log_q=log_q, capture_q=cap_q,
)
threading.Thread(target=proxy2.start, daemon=True).start()
time.sleep(0.4)

real_getaddrinfo = socket.getaddrinfo
def fake_getaddrinfo(host, port, *a, **k):
    if host == "rockstargames.com":
        return real_getaddrinfo("127.0.0.1", port, *a, **k)
    return real_getaddrinfo(host, port, *a, **k)

real_default_context = ssl.create_default_context
def patched_default_context(*a, **k):
    ctx = real_default_context(*a, **k)
    ctx.load_verify_locations(fca)
    return ctx

socket.getaddrinfo = fake_getaddrinfo
ssl.create_default_context = patched_default_context
ctx_client = ssl.create_default_context()

try:
    s = socket.create_connection(("127.0.0.1", proxy_port), timeout=5)
    s.sendall(f"CONNECT rockstargames.com:{fake_port} HTTP/1.1\r\nHost: rockstargames.com:{fake_port}\r\n\r\n".encode())
    resp = s.recv(4096)
    assert b"200" in resp, f"CONNECT failed: {resp!r}"

    tls = ctx_client.wrap_socket(s, server_hostname="rockstargames.com")
    tls.sendall(b"GET /profile/character HTTP/1.1\r\nHost: rockstargames.com\r\nConnection: close\r\n\r\n")
    body = b""
    while True:
        chunk = tls.recv(8192)
        if not chunk: break
        body += chunk
    tls.close()

    assert b"characterData" in body, f"Response missing character data: {body[:200]!r}"
    ok("end-to-end MITM intercept + forward worked")
except Exception as e:
    fail("live MITM test", f"{type(e).__name__}: {e}")
    import traceback; traceback.print_exc()
finally:
    socket.getaddrinfo = real_getaddrinfo
    ssl.create_default_context = real_default_context

time.sleep(0.5)
captures = []
while not cap_q.empty():
    captures.append(cap_q.get())

if any(c.is_char for c in captures):
    ok("character payload captured AND flagged in queue")
elif captures:
    fail("captured but not flagged as character", str([c.label for c in captures]))
else:
    fail("nothing captured", "")

print("Test 12: INJECT mode replacement...")
INJECTED_BODY = b'{"characterData":{"name":"InjectedSuperHero","money":999999999,"rank":8000}}'
inj_cap = rsc.Capture("rockstargames.com", "/profile/character", "GET", 200,
                      INJECTED_BODY, "application/json", 0)
proxy2.set_inject(True, {"rockstargames.com/profile/character": inj_cap})

try:
    socket.getaddrinfo = fake_getaddrinfo
    ssl.create_default_context = patched_default_context
    s = socket.create_connection(("127.0.0.1", proxy_port), timeout=5)
    s.sendall(f"CONNECT rockstargames.com:{fake_port} HTTP/1.1\r\nHost: rockstargames.com:{fake_port}\r\n\r\n".encode())
    resp = s.recv(4096)
    assert b"200" in resp
    tls = ctx_client.wrap_socket(s, server_hostname="rockstargames.com")
    tls.sendall(b"GET /profile/character HTTP/1.1\r\nHost: rockstargames.com\r\nConnection: close\r\n\r\n")
    body = b""
    while True:
        chunk = tls.recv(8192)
        if not chunk: break
        body += chunk
    tls.close()
    if b"InjectedSuperHero" in body and b"999999999" in body:
        ok("inject mode replaced response with our payload")
    else:
        fail("inject didn't replace response", f"body tail: {body[-300:]!r}")
except Exception as e:
    fail("inject live test", f"{type(e).__name__}: {e}")
finally:
    socket.getaddrinfo = real_getaddrinfo
    ssl.create_default_context = real_default_context

proxy2.stop()
srv.shutdown()
for p in (fcrt, fkey, fca): os.unlink(p)

print()
print(f"========== Result: {passed} passed, {failed} failed ==========")
sys.exit(0 if failed == 0 else 1)
